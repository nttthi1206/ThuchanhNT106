﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB2
{
    public partial class BAI7 : Form
    {
        public BAI7()
        {
            InitializeComponent();
        }

        private void BAI7_Load(object sender, EventArgs e)
        {
            // Populate drives in the TreeView
            treeView1.Nodes.Clear();
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (drive.IsReady)
                {
                    TreeNode node = new TreeNode(drive.Name);
                    node.Tag = drive.Name;
                    node.Nodes.Add("..."); // Dummy node for expand
                    treeView1.Nodes.Add(node);
                }
            }
            groupBoxContent.Text = "File Content";
            richTextBoxContent.Visible = false;
            pictureBoxContent.Visible = false;
        }

        // Expand node to show subdirectories and files
        private void treeView1_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            TreeNode node = e.Node;
            if (node.Nodes.Count == 1 && node.Nodes[0].Text == "...")
            {
                node.Nodes.Clear();
                string path = node.Tag as string;
                try
                {
                    // Add directories
                    foreach (var dir in Directory.GetDirectories(path))
                    {
                        TreeNode dirNode = new TreeNode(Path.GetFileName(dir));
                        dirNode.Tag = dir;
                        dirNode.Nodes.Add("...");
                        node.Nodes.Add(dirNode);
                    }
                    // Add files
                    foreach (var file in Directory.GetFiles(path))
                    {
                        TreeNode fileNode = new TreeNode(Path.GetFileName(file));
                        fileNode.Tag = file;
                        node.Nodes.Add(fileNode);
                    }
                }
                catch { /* Ignore access errors */ }
            }
        }

        // Handle file/folder selection
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            string path = e.Node.Tag as string;
            if (Directory.Exists(path))
            {
                // Folder selected, clear content
                groupBoxContent.Text = "File Content";
                richTextBoxContent.Visible = false;
                pictureBoxContent.Visible = false;
            }
            else if (File.Exists(path))
            {
                string ext = Path.GetExtension(path).ToLower();
                groupBoxContent.Text = "File Content";
                try
                {
                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".bmp" || ext == ".gif")
                    {
                        if (pictureBoxContent.Image != null)
                        {
                            pictureBoxContent.Image.Dispose();
                            pictureBoxContent.Image = null;
                        }
                        pictureBoxContent.Image = Image.FromFile(path);
                        pictureBoxContent.Visible = true;
                        richTextBoxContent.Visible = false;
                    }
                    else
                    {
                        richTextBoxContent.Text = File.ReadAllText(path);
                        richTextBoxContent.Visible = true;
                        pictureBoxContent.Visible = false;
                        if (pictureBoxContent.Image != null)
                        {
                            pictureBoxContent.Image.Dispose();
                            pictureBoxContent.Image = null;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không thể đọc file: " + ex.Message);
                    richTextBoxContent.Visible = false;
                    pictureBoxContent.Visible = false;
                }
            }
        }
    }
}
