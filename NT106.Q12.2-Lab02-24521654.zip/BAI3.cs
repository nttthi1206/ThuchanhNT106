﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace LAB2
{
    public partial class BAI3 : Form
    {
        public BAI3()
        {
            InitializeComponent();
        }

        private void btnRunBai3_Click(object sender, EventArgs e)
        {
            string inputFile = "input3.txt";
            string outputFile = "output3.txt";

            rtbContent.Clear();

            try
            {
                string[] lines = File.ReadAllLines(inputFile);

                using (StreamWriter sw = new StreamWriter(outputFile))
                {
                    foreach (string line in lines)
                    {
                        if (string.IsNullOrWhiteSpace(line))
                            continue; //bỏ qua nếu la dòng trống 

                        double result = CalculateExpression(line); // gọi hàm tính toán
                        string resultLine = line + " = " + result.ToString(System.Globalization.CultureInfo.InvariantCulture);

                        sw.WriteLine(line + " = " + result.ToString()); //ghi kết quả vào file output 
                        sw.WriteLine(resultLine);
                        rtbContent.AppendText(resultLine + "\n");
                    }

                }
                MessageBox.Show("Đã tính toán và ghi ra file output3.txt thành công! ");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message);
            }

        }




        //Calculate expression dùng để xừ lý các biểu thức đơn giản( cộng, trừ) từ trái sang phải bằng cách tách chuỗi dựa trên dấu cách

        private double CalculateExpression(string expression)
        {
            try
            {
                // tách chuỗi thành các số và toán tử
                string[] parts = expression.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                double result = double.Parse(parts[0], CultureInfo.InvariantCulture);
                for (int i = 1; i < parts.Length; i += 2)
                {
                    string op = parts[i];
                    double nextNumber = double.Parse(parts[i + 1]);
                    double number = double.Parse(parts[i + 1], CultureInfo.InvariantCulture);
                    if (op == "+")
                    {
                        result += number;
                    }
                    else if (op == "-")
                    {
                        result -= number;
                    }
                }
                return result;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi trong biểu thức: " + expression + "\n" + ex.Message);
                return 0;
            }

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}



