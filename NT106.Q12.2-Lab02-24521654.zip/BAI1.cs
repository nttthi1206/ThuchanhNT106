﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB2
{
    public partial class BAI1 : Form
    {
        public BAI1()
        {
            InitializeComponent();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader("input1.txt");
            rtbContent.Text = sr.ReadToEnd();
            sr.Close();
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("output1.txt");
            string content = rtbContent.Text.ToUpper(); // Chuyển sang chữ hoa
            sw.Write(content);
            sw.Close();
            MessageBox.Show("Đã ghi file thành công!");
        }
    }
}
