﻿namespace LAB2
{
    partial class BAI5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox1 = new TextBox();
            btnThongKe = new Button();
            process1 = new System.Diagnostics.Process();
            progressBar2 = new ProgressBar();
            SuspendLayout();
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "1", "2", "3" });
            comboBox2.Location = new Point(337, 266);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 28);
            comboBox2.TabIndex = 19;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Đào, phở và piano", "Mai", "Gặp lại chị bầu", "Tarot" });
            comboBox1.Location = new Point(337, 197);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 18;
            // 
            // button2
            // 
            button2.Location = new Point(476, 357);
            button2.Name = "button2";
            button2.Size = new Size(109, 37);
            button2.TabIndex = 17;
            button2.Text = "Thoát";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(327, 357);
            button1.Name = "button1";
            button1.Size = new Size(109, 37);
            button1.TabIndex = 16;
            button1.Text = "Xác nhận";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(225, 269);
            label4.Name = "label4";
            label4.Size = new Size(90, 20);
            label4.TabIndex = 15;
            label4.Text = "Phòng chiếu";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(225, 199);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 14;
            label3.Text = "Tên Phim";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(225, 129);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 13;
            label2.Text = "Họ và tên";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(130, 57);
            label1.Name = "label1";
            label1.Size = new Size(455, 35);
            label1.TabIndex = 12;
            label1.Text = "ĐẶT VÉ, XEM PHIM VÀ CHILL";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(338, 122);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 27);
            textBox1.TabIndex = 11;
            // 
            // btnThongKe
            // 
            btnThongKe.Location = new Point(625, 366);
            btnThongKe.Name = "btnThongKe";
            btnThongKe.Size = new Size(125, 37);
            btnThongKe.TabIndex = 20;
            btnThongKe.Text = "Xuất Báo Cáo";
            btnThongKe.UseVisualStyleBackColor = true;
            btnThongKe.Click += btnThongKe_Click;
            // 
            // process1
            // 
            process1.StartInfo.Domain = "";
            process1.StartInfo.LoadUserProfile = false;
            process1.StartInfo.Password = null;
            process1.StartInfo.StandardErrorEncoding = null;
            process1.StartInfo.StandardInputEncoding = null;
            process1.StartInfo.StandardOutputEncoding = null;
            process1.StartInfo.UseCredentialsForNetworkingOnly = false;
            process1.StartInfo.UserName = "";
            process1.SynchronizingObject = this;
            process1.Exited += process1_Exited;
            // 
            // progressBar2
            // 
            progressBar2.Location = new Point(625, 409);
            progressBar2.Name = "progressBar2";
            progressBar2.Size = new Size(125, 29);
            progressBar2.TabIndex = 21;
            progressBar2.Click += progressBar2_Click;
            // 
            // BAI5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(progressBar2);
            Controls.Add(btnThongKe);
            Controls.Add(comboBox2);
            Controls.Add(comboBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Name = "BAI5";
            Text = "BAI5";
            Load += BAI5_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private Button button2;
        private Button button1;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private Button btnThongKe;
        private System.Diagnostics.Process process1;
        private ProgressBar progressBar1;
        private ProgressBar progressBar2;
    }
}