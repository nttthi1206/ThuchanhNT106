﻿using System.IO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB2
{
    public partial class BAI2 : Form
    {
        public BAI2()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }


        private void btnRead_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text Files (*.txt)|*.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(ofd.FileName, FileMode.Open))
                {
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        string content = sr.ReadToEnd();
                        rtbContent.Text = content;


                        txtFileName.Text = ofd.SafeFileName;

                        txtUrl.Text = fs.Name;

                        txtSize.Text = fs.Length.ToString() + " bytes";

                        txtCharCount.Text = content.Length.ToString();

                        string[] lines = content.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                        txtLineCount.Text = lines.Length.ToString();

                        string[] words = content.Split(new char[] { ' ', '\t', '\r', '\n' },
                                                     StringSplitOptions.RemoveEmptyEntries);
                        txtWordCount.Text = words.Length.ToString();
                    }
                }
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        { 
            this.Close();
        }
    }
}

