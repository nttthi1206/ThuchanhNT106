﻿namespace LAB2
{
    partial class BAI4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGhiFile = new Button();
            txtHoTen_Input = new TextBox();
            txtMSSV_Input = new TextBox();
            txtDienThoai_Input = new TextBox();
            txtDiem1_Input = new TextBox();
            txtDiem2_Input = new TextBox();
            txtDiem3_Input = new TextBox();
            txtDTB_Input = new TextBox();
            btnThem = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            lblAverageInput = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            btnTruoc = new Button();
            txtDiemTB_Display = new TextBox();
            txtDiem3_Display = new TextBox();
            txtDiem2_Display = new TextBox();
            txtDiem1_Display = new TextBox();
            txtDienThoai_Display = new TextBox();
            txtMSSV_Display = new TextBox();
            txtHoTen_Display = new TextBox();
            btnDocFile = new Button();
            btnSau = new Button();
            rtbDanhSach = new RichTextBox();
            SuspendLayout();
            // 
            // btnGhiFile
            // 
            btnGhiFile.Location = new Point(12, 12);
            btnGhiFile.Name = "btnGhiFile";
            btnGhiFile.Size = new Size(222, 32);
            btnGhiFile.TabIndex = 0;
            btnGhiFile.Text = "Write to a File ";
            btnGhiFile.UseVisualStyleBackColor = true;
            btnGhiFile.Click += btnWriteFile_Click;
            // 
            // txtHoTen_Input
            // 
            txtHoTen_Input.Location = new Point(12, 65);
            txtHoTen_Input.Name = "txtHoTen_Input";
            txtHoTen_Input.Size = new Size(155, 27);
            txtHoTen_Input.TabIndex = 1;
            // 
            // txtMSSV_Input
            // 
            txtMSSV_Input.Location = new Point(12, 110);
            txtMSSV_Input.Name = "txtMSSV_Input";
            txtMSSV_Input.Size = new Size(155, 27);
            txtMSSV_Input.TabIndex = 2;
            // 
            // txtDienThoai_Input
            // 
            txtDienThoai_Input.Location = new Point(12, 158);
            txtDienThoai_Input.Name = "txtDienThoai_Input";
            txtDienThoai_Input.Size = new Size(155, 27);
            txtDienThoai_Input.TabIndex = 3;
            // 
            // txtDiem1_Input
            // 
            txtDiem1_Input.Location = new Point(12, 208);
            txtDiem1_Input.Name = "txtDiem1_Input";
            txtDiem1_Input.Size = new Size(155, 27);
            txtDiem1_Input.TabIndex = 4;
            // 
            // txtDiem2_Input
            // 
            txtDiem2_Input.Location = new Point(12, 262);
            txtDiem2_Input.Name = "txtDiem2_Input";
            txtDiem2_Input.Size = new Size(155, 27);
            txtDiem2_Input.TabIndex = 5;
            // 
            // txtDiem3_Input
            // 
            txtDiem3_Input.Location = new Point(12, 310);
            txtDiem3_Input.Name = "txtDiem3_Input";
            txtDiem3_Input.Size = new Size(155, 27);
            txtDiem3_Input.TabIndex = 6;
            // 
            // txtDTB_Input
            // 
            txtDTB_Input.Location = new Point(12, 361);
            txtDTB_Input.Name = "txtDTB_Input";
            txtDTB_Input.Size = new Size(155, 27);
            txtDTB_Input.TabIndex = 7;
            // 
            // btnThem
            // 
            btnThem.Location = new Point(86, 409);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(94, 29);
            btnThem.TabIndex = 8;
            btnThem.Text = " Add";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnAdd_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(173, 70);
            label1.Name = "label1";
            label1.Size = new Size(53, 20);
            label1.TabIndex = 9;
            label1.Text = " Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(173, 117);
            label2.Name = "label2";
            label2.Size = new Size(28, 20);
            label2.TabIndex = 10;
            label2.Text = " ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(173, 165);
            label3.Name = "label3";
            label3.Size = new Size(54, 20);
            label3.TabIndex = 11;
            label3.Text = " Phone";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(166, 213);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 12;
            label4.Text = " Course 1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(164, 269);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 13;
            label5.Text = " Course 2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(165, 317);
            label6.Name = "label6";
            label6.Size = new Size(70, 20);
            label6.TabIndex = 14;
            label6.Text = " Course 3";
            // 
            // lblAverageInput
            // 
            lblAverageInput.AutoSize = true;
            lblAverageInput.Location = new Point(165, 369);
            lblAverageInput.Name = "lblAverageInput";
            lblAverageInput.Size = new Size(68, 20);
            lblAverageInput.TabIndex = 15;
            lblAverageInput.Text = " Average";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(708, 368);
            label8.Name = "label8";
            label8.Size = new Size(68, 20);
            label8.TabIndex = 32;
            label8.Text = " Average";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(710, 317);
            label9.Name = "label9";
            label9.Size = new Size(66, 20);
            label9.TabIndex = 31;
            label9.Text = "Course 3";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(706, 269);
            label10.Name = "label10";
            label10.Size = new Size(70, 20);
            label10.TabIndex = 30;
            label10.Text = " Course 2";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(706, 211);
            label11.Name = "label11";
            label11.Size = new Size(70, 20);
            label11.TabIndex = 29;
            label11.Text = " Course 1";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(726, 165);
            label12.Name = "label12";
            label12.Size = new Size(50, 20);
            label12.TabIndex = 28;
            label12.Text = "Phone";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(748, 117);
            label13.Name = "label13";
            label13.Size = new Size(28, 20);
            label13.TabIndex = 27;
            label13.Text = " ID";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(723, 77);
            label14.Name = "label14";
            label14.Size = new Size(53, 20);
            label14.TabIndex = 26;
            label14.Text = " Name";
            // 
            // btnTruoc
            // 
            btnTruoc.Location = new Point(531, 409);
            btnTruoc.Name = "btnTruoc";
            btnTruoc.Size = new Size(94, 29);
            btnTruoc.TabIndex = 25;
            btnTruoc.Text = "Back";
            btnTruoc.UseVisualStyleBackColor = true;
            btnTruoc.Click += btnBack_Click;
            // 
            // txtDiemTB_Display
            // 
            txtDiemTB_Display.BackColor = SystemColors.ButtonHighlight;
            txtDiemTB_Display.Location = new Point(531, 366);
            txtDiemTB_Display.Name = "txtDiemTB_Display";
            txtDiemTB_Display.ReadOnly = true;
            txtDiemTB_Display.Size = new Size(171, 27);
            txtDiemTB_Display.TabIndex = 24;
            // 
            // txtDiem3_Display
            // 
            txtDiem3_Display.BackColor = SystemColors.ButtonHighlight;
            txtDiem3_Display.Location = new Point(531, 315);
            txtDiem3_Display.Name = "txtDiem3_Display";
            txtDiem3_Display.ReadOnly = true;
            txtDiem3_Display.Size = new Size(171, 27);
            txtDiem3_Display.TabIndex = 23;
            // 
            // txtDiem2_Display
            // 
            txtDiem2_Display.BackColor = SystemColors.ButtonHighlight;
            txtDiem2_Display.Location = new Point(531, 267);
            txtDiem2_Display.Name = "txtDiem2_Display";
            txtDiem2_Display.ReadOnly = true;
            txtDiem2_Display.Size = new Size(171, 27);
            txtDiem2_Display.TabIndex = 22;
            // 
            // txtDiem1_Display
            // 
            txtDiem1_Display.BackColor = SystemColors.ButtonHighlight;
            txtDiem1_Display.Location = new Point(531, 213);
            txtDiem1_Display.Name = "txtDiem1_Display";
            txtDiem1_Display.ReadOnly = true;
            txtDiem1_Display.Size = new Size(171, 27);
            txtDiem1_Display.TabIndex = 21;
            // 
            // txtDienThoai_Display
            // 
            txtDienThoai_Display.BackColor = SystemColors.ButtonHighlight;
            txtDienThoai_Display.Location = new Point(531, 163);
            txtDienThoai_Display.Name = "txtDienThoai_Display";
            txtDienThoai_Display.ReadOnly = true;
            txtDienThoai_Display.Size = new Size(171, 27);
            txtDienThoai_Display.TabIndex = 20;
            // 
            // txtMSSV_Display
            // 
            txtMSSV_Display.BackColor = SystemColors.ButtonHighlight;
            txtMSSV_Display.Location = new Point(531, 115);
            txtMSSV_Display.Name = "txtMSSV_Display";
            txtMSSV_Display.ReadOnly = true;
            txtMSSV_Display.Size = new Size(171, 27);
            txtMSSV_Display.TabIndex = 19;
            // 
            // txtHoTen_Display
            // 
            txtHoTen_Display.BackColor = SystemColors.ButtonHighlight;
            txtHoTen_Display.Location = new Point(531, 65);
            txtHoTen_Display.Name = "txtHoTen_Display";
            txtHoTen_Display.ReadOnly = true;
            txtHoTen_Display.Size = new Size(171, 27);
            txtHoTen_Display.TabIndex = 18;
            // 
            // btnDocFile
            // 
            btnDocFile.Location = new Point(531, 17);
            btnDocFile.Name = "btnDocFile";
            btnDocFile.Size = new Size(245, 32);
            btnDocFile.TabIndex = 17;
            btnDocFile.Text = " Button to read a File";
            btnDocFile.UseVisualStyleBackColor = true;
            btnDocFile.Click += btnReadFile_Click;
            // 
            // btnSau
            // 
            btnSau.Location = new Point(667, 409);
            btnSau.Name = "btnSau";
            btnSau.Size = new Size(94, 29);
            btnSau.TabIndex = 33;
            btnSau.Text = " Next";
            btnSau.UseVisualStyleBackColor = true;
            btnSau.Click += btnSau_Click;
            // 
            // rtbDanhSach
            // 
            rtbDanhSach.Location = new Point(240, 12);
            rtbDanhSach.Name = "rtbDanhSach";
            rtbDanhSach.Size = new Size(285, 426);
            rtbDanhSach.TabIndex = 34;
            rtbDanhSach.Text = "";
            // 
            // BAI4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(rtbDanhSach);
            Controls.Add(btnSau);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(label14);
            Controls.Add(btnTruoc);
            Controls.Add(txtDiemTB_Display);
            Controls.Add(txtDiem3_Display);
            Controls.Add(txtDiem2_Display);
            Controls.Add(txtDiem1_Display);
            Controls.Add(txtDienThoai_Display);
            Controls.Add(txtMSSV_Display);
            Controls.Add(txtHoTen_Display);
            Controls.Add(btnDocFile);
            Controls.Add(lblAverageInput);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnThem);
            Controls.Add(txtDTB_Input);
            Controls.Add(txtDiem3_Input);
            Controls.Add(txtDiem2_Input);
            Controls.Add(txtDiem1_Input);
            Controls.Add(txtDienThoai_Input);
            Controls.Add(txtMSSV_Input);
            Controls.Add(txtHoTen_Input);
            Controls.Add(btnGhiFile);
            Name = "BAI4";
            Text = "BAI4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGhiFile;
        private TextBox txtHoTen_Input;
        private TextBox txtMSSV_Input;
        private TextBox txtDienThoai_Input;
        private TextBox txtDiem1_Input;
        private TextBox txtDiem2_Input;
        private TextBox txtDiem3_Input;
        private TextBox txtDTB_Input;
        private Button btnThem;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label lblAverageInput;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Button btnTruoc;
        private TextBox txtDiemTB_Display;
        private TextBox txtDiem3_Display;
        private TextBox txtDiem2_Display;
        private TextBox txtDiem1_Display;
        private TextBox txtDienThoai_Display;
        private TextBox txtMSSV_Display;
        private TextBox txtHoTen_Display;
        private Button btnDocFile;
        private Button btnSau;
        private RichTextBox rtbDanhSach;
    }
}