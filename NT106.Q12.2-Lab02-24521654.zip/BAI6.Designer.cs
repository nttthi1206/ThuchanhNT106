﻿namespace LAB2
{
    partial class BAI6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            pictureBoxMonAn = new PictureBox();
            buttonChonNgauNhien = new Button();
            txtKetQuaMonAn = new TextBox();
            label1 = new Label();
            txtKetQuaNguoiDung = new TextBox();
            label2 = new Label();
            groupBox1 = new GroupBox();
            buttonThemMonAn = new Button();
            label5 = new Label();
            cmbNguoiDung = new ComboBox();
            txtHinhAnh = new TextBox();
            label4 = new Label();
            txtTenMonAn = new TextBox();
            label3 = new Label();
            groupBox2 = new GroupBox();
            buttonThemNguoiDung = new Button();
            txtQuyenHan = new TextBox();
            label7 = new Label();
            txtHoVaTen = new TextBox();
            label6 = new Label();
            button4 = new Button();
            btnChonAnh = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMonAn).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Location = new Point(12, 15);
            listView1.Margin = new Padding(3, 4, 3, 4);
            listView1.Name = "listView1";
            listView1.Size = new Size(460, 390);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // pictureBoxMonAn
            // 
            pictureBoxMonAn.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxMonAn.Location = new Point(490, 15);
            pictureBoxMonAn.Margin = new Padding(3, 4, 3, 4);
            pictureBoxMonAn.Name = "pictureBoxMonAn";
            pictureBoxMonAn.Size = new Size(298, 232);
            pictureBoxMonAn.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxMonAn.TabIndex = 1;
            pictureBoxMonAn.TabStop = false;
            // 
            // buttonChonNgauNhien
            // 
            buttonChonNgauNhien.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonChonNgauNhien.Location = new Point(490, 351);
            buttonChonNgauNhien.Margin = new Padding(3, 4, 3, 4);
            buttonChonNgauNhien.Name = "buttonChonNgauNhien";
            buttonChonNgauNhien.Size = new Size(298, 55);
            buttonChonNgauNhien.TabIndex = 2;
            buttonChonNgauNhien.Text = "Hôm nay ăn gì?";
            buttonChonNgauNhien.UseVisualStyleBackColor = true;
            buttonChonNgauNhien.Click += buttonChonNgauNhien_Click;
            // 
            // txtKetQuaMonAn
            // 
            txtKetQuaMonAn.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtKetQuaMonAn.Location = new Point(578, 255);
            txtKetQuaMonAn.Margin = new Padding(3, 4, 3, 4);
            txtKetQuaMonAn.Name = "txtKetQuaMonAn";
            txtKetQuaMonAn.ReadOnly = true;
            txtKetQuaMonAn.Size = new Size(210, 27);
            txtKetQuaMonAn.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(487, 262);
            label1.Name = "label1";
            label1.Size = new Size(64, 20);
            label1.TabIndex = 4;
            label1.Text = "Món Ăn:";
            // 
            // txtKetQuaNguoiDung
            // 
            txtKetQuaNguoiDung.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtKetQuaNguoiDung.Location = new Point(578, 296);
            txtKetQuaNguoiDung.Margin = new Padding(3, 4, 3, 4);
            txtKetQuaNguoiDung.Name = "txtKetQuaNguoiDung";
            txtKetQuaNguoiDung.ReadOnly = true;
            txtKetQuaNguoiDung.Size = new Size(210, 27);
            txtKetQuaNguoiDung.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(487, 304);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 6;
            label2.Text = "Người ĐG:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnChonAnh);
            groupBox1.Controls.Add(buttonThemMonAn);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(cmbNguoiDung);
            groupBox1.Controls.Add(txtHinhAnh);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(txtTenMonAn);
            groupBox1.Controls.Add(label3);
            groupBox1.Location = new Point(12, 414);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(380, 194);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thêm Món Ăn";
            // 
            // buttonThemMonAn
            // 
            buttonThemMonAn.Location = new Point(268, 142);
            buttonThemMonAn.Margin = new Padding(3, 4, 3, 4);
            buttonThemMonAn.Name = "buttonThemMonAn";
            buttonThemMonAn.Size = new Size(106, 36);
            buttonThemMonAn.TabIndex = 6;
            buttonThemMonAn.Text = "Thêm Món";
            buttonThemMonAn.UseVisualStyleBackColor = true;
            buttonThemMonAn.Click += buttonThemMonAn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 109);
            label5.Name = "label5";
            label5.Size = new Size(79, 20);
            label5.TabIndex = 5;
            label5.Text = "Người ĐG:";
            // 
            // cmbNguoiDung
            // 
            cmbNguoiDung.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbNguoiDung.FormattingEnabled = true;
            cmbNguoiDung.Location = new Point(92, 105);
            cmbNguoiDung.Margin = new Padding(3, 4, 3, 4);
            cmbNguoiDung.Name = "cmbNguoiDung";
            cmbNguoiDung.Size = new Size(282, 28);
            cmbNguoiDung.TabIndex = 4;
            // 
            // txtHinhAnh
            // 
            txtHinhAnh.Location = new Point(92, 70);
            txtHinhAnh.Margin = new Padding(3, 4, 3, 4);
            txtHinhAnh.Name = "txtHinhAnh";
            txtHinhAnh.Size = new Size(170, 27);
            txtHinhAnh.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 74);
            label4.Name = "label4";
            label4.Size = new Size(73, 20);
            label4.TabIndex = 2;
            label4.Text = "Hình Ảnh:";
            // 
            // txtTenMonAn
            // 
            txtTenMonAn.Location = new Point(92, 35);
            txtTenMonAn.Margin = new Padding(3, 4, 3, 4);
            txtTenMonAn.Name = "txtTenMonAn";
            txtTenMonAn.Size = new Size(282, 27);
            txtTenMonAn.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 39);
            label3.Name = "label3";
            label3.Size = new Size(69, 20);
            label3.TabIndex = 0;
            label3.Text = "Tên Món:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(buttonThemNguoiDung);
            groupBox2.Controls.Add(txtQuyenHan);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(txtHoVaTen);
            groupBox2.Controls.Add(label6);
            groupBox2.Location = new Point(408, 414);
            groupBox2.Margin = new Padding(3, 4, 3, 4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(3, 4, 3, 4);
            groupBox2.Size = new Size(380, 152);
            groupBox2.TabIndex = 8;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thêm Người Dùng";
            // 
            // buttonThemNguoiDung
            // 
            buttonThemNguoiDung.Location = new Point(268, 109);
            buttonThemNguoiDung.Margin = new Padding(3, 4, 3, 4);
            buttonThemNguoiDung.Name = "buttonThemNguoiDung";
            buttonThemNguoiDung.Size = new Size(106, 36);
            buttonThemNguoiDung.TabIndex = 7;
            buttonThemNguoiDung.Text = "Thêm Người";
            buttonThemNguoiDung.UseVisualStyleBackColor = true;
            buttonThemNguoiDung.Click += buttonThemNguoiDung_Click;
            // 
            // txtQuyenHan
            // 
            txtQuyenHan.Location = new Point(92, 74);
            txtQuyenHan.Margin = new Padding(3, 4, 3, 4);
            txtQuyenHan.Name = "txtQuyenHan";
            txtQuyenHan.Size = new Size(282, 27);
            txtQuyenHan.TabIndex = 5;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 78);
            label7.Name = "label7";
            label7.Size = new Size(85, 20);
            label7.TabIndex = 4;
            label7.Text = "Quyền Hạn:";
            // 
            // txtHoVaTen
            // 
            txtHoVaTen.Location = new Point(92, 39);
            txtHoVaTen.Margin = new Padding(3, 4, 3, 4);
            txtHoVaTen.Name = "txtHoVaTen";
            txtHoVaTen.Size = new Size(282, 27);
            txtHoVaTen.TabIndex = 3;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 42);
            label6.Name = "label6";
            label6.Size = new Size(78, 20);
            label6.TabIndex = 2;
            label6.Text = "Họ và Tên:";
            // 
            // button4
            // 
            button4.BackColor = Color.MistyRose;
            button4.Location = new Point(682, 574);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(106, 36);
            button4.TabIndex = 8;
            button4.Text = "Thoát";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // btnChonAnh
            // 
            btnChonAnh.Location = new Point(268, 70);
            btnChonAnh.Margin = new Padding(3, 4, 3, 4);
            btnChonAnh.Name = "btnChonAnh";
            btnChonAnh.Size = new Size(106, 27);
            btnChonAnh.TabIndex = 7;
            btnChonAnh.Text = "Chọn Hình";
            btnChonAnh.UseVisualStyleBackColor = true;
            btnChonAnh.Click += btnChonAnh_Click;
            // 
            // BAI6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 622);
            Controls.Add(button4);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label2);
            Controls.Add(txtKetQuaNguoiDung);
            Controls.Add(label1);
            Controls.Add(txtKetQuaMonAn);
            Controls.Add(buttonChonNgauNhien);
            Controls.Add(pictureBoxMonAn);
            Controls.Add(listView1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "BAI6";
            Text = "Bài 6 - Hôm nay ăn gì? (Bản SQLite)";
            ((System.ComponentModel.ISupportInitialize)pictureBoxMonAn).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.PictureBox pictureBoxMonAn;
        private System.Windows.Forms.Button buttonChonNgauNhien;
        private System.Windows.Forms.TextBox txtKetQuaMonAn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtKetQuaNguoiDung;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonThemMonAn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbNguoiDung;
        private System.Windows.Forms.TextBox txtHinhAnh;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTenMonAn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttonThemNguoiDung;
        private System.Windows.Forms.TextBox txtQuyenHan;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtHoVaTen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button4;
        private Button btnChonAnh;
    }
}