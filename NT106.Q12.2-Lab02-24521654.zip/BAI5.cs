﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LAB2
{
    public partial class BAI5 : Form
    {

        Dictionary<string, (int GiaVe, int[] PhongChieu)> danhSachPhim = new Dictionary<string, (int, int[])>()
        {

        };
        public BAI5()
        {
            InitializeComponent();
            this.Load += BAI5_Load;

        }

        private void BAI5_Load(object sender, EventArgs e)
        {
            // Gán event handler cho comboBox1
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;

            // Xóa các items mặc định trong comboBox2
            comboBox2.Items.Clear();
            comboBox2.Text = "";

            string inputPath = Path.Combine(Application.StartupPath, "input5.txt");
            LoadPhimTuFile(inputPath);

            foreach (var tenPhim in danhSachPhim.Keys)
            {
                comboBox1.Items.Add(tenPhim);
            }
        }
        private void LoadPhimTuFile(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Không tìm thấy file input5.txt!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string[] lines = File.ReadAllLines(filePath);

                for (int i = 0; i < lines.Length; i += 3)
                {
                    // THÊM KIỂM TRA: Đảm bảo có đủ 3 dòng để đọc
                    if (i + 2 < lines.Length)
                    {
                        string tenPhim = lines[i];
                        int giaVe = int.Parse(lines[i + 1]);
                        int[] phongChieu = lines[i + 2].Split(',').Select(int.Parse).ToArray();

                        // THÊM KIỂM TRA: Đảm bảo phim chưa tồn tại
                        if (!danhSachPhim.ContainsKey(tenPhim))
                        {
                            danhSachPhim.Add(tenPhim, (giaVe, phongChieu));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đọc file input5.txt: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CapNhatPhongChieu();
        }
        private void CapNhatPhongChieu()
        {
            // Xóa danh sách phòng chiếu hiện tại
            comboBox2.Items.Clear();
            comboBox2.Text = "";

            string tenPhimDaChon = comboBox1.Text;

            // Nếu có phim được chọn và tồn tại trong dictionary
            if (!string.IsNullOrEmpty(tenPhimDaChon) && danhSachPhim.ContainsKey(tenPhimDaChon))
            {
                var phongChieuArray = danhSachPhim[tenPhimDaChon].PhongChieu;

                // Thêm các phòng chiếu tương ứng vào comboBox2
                foreach (int phong in phongChieuArray)
                {
                    comboBox2.Items.Add(phong.ToString());
                }

                // Chọn option đầu tiên làm mặc định
                if (comboBox2.Items.Count > 0)
                {
                    comboBox2.SelectedIndex = 0;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tenPhim = comboBox1.Text;
            string phongChieu = comboBox2.Text;
            string hoTen = textBox1.Text;

            if (string.IsNullOrWhiteSpace(hoTen))
            {
                MessageBox.Show("Vui lòng nhập họ và tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(tenPhim))
            {
                MessageBox.Show("Vui lòng chọn phim!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(phongChieu))
            {
                MessageBox.Show("Vui lòng chọn phòng chiếu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy giá vé từ dictionary
            if (danhSachPhim.ContainsKey(tenPhim))
            {
                int giaVe = danhSachPhim[tenPhim].GiaVe;
                BAI5_1 f = new BAI5_1(hoTen, tenPhim, phongChieu, giaVe);
                this.Hide();
                f.Show();
            }
            else
            {
                MessageBox.Show("Phim không tồn tại trong danh sách!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            // 1. Khởi tạo danh sách thống kê từ danhSachPhim
            //    (danhSachPhim này đã được load từ file input5.txt ở bước 1)
            Dictionary<string, PhimStats> stats = new Dictionary<string, PhimStats>();
            foreach (var phimEntry in danhSachPhim)
            {
                string tenPhim = phimEntry.Key;
                int[] phongChieu = phimEntry.Value.PhongChieu;

                // Mỗi phòng có 15 ghế (A1-C5)
                int tongSoGhe = phongChieu.Length * 15;

                stats.Add(tenPhim, new PhimStats
                {
                    TenPhim = tenPhim,
                    SoVeTon = tongSoGhe // Ban đầu, vé tồn = tổng số ghế
                });
            }

            // 2. Đọc file sales.txt để tính toán
            string salesPath = Path.Combine(Application.StartupPath, "sales.txt");
            if (File.Exists(salesPath))
            {
                string[] salesLines = File.ReadAllLines(salesPath);

                // Cấu hình ProgressBar
                progressBar2.Minimum = 0;
                progressBar2.Maximum = salesLines.Length > 0 ? salesLines.Length : 1;
                progressBar2.Value = 0;
                if (salesLines.Length > 0)
                {
                    foreach (string line in salesLines)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length >= 5)
                        {
                            string tenPhim = parts[1];
                            if (int.TryParse(parts[4], out int giaVe))
                            {


                                if (stats.ContainsKey(tenPhim))
                                {
                                    stats[tenPhim].SoVeDaBan++;
                                    stats[tenPhim].SoVeTon--; // Giảm vé tồn
                                    stats[tenPhim].TongDoanhThu += giaVe;
                                }
                            }
                            if (progressBar2.Value < progressBar2.Maximum)
                            {
                                progressBar2.Value++;
                            }
                        }
                    }
                } 
                else 
                {
                    progressBar2.Value = 1;
                }
            }
            else // Sửa Lỗi 3: Thêm khối else
            {
                // Hoàn thành ngay nếu file không tồn tại
                progressBar2.Minimum = 0;
                progressBar2.Maximum = 1;
                progressBar2.Value = 1;
            }

            // 3. Sắp xếp theo doanh thu giảm dần
            var rankedList = stats.Values.OrderByDescending(s => s.TongDoanhThu).ToList();

            // 4. Ghi ra file output5.txt
            try
            {
                string outputPath = Path.Combine(Application.StartupPath, "output5.txt");
                using (StreamWriter sw = new StreamWriter(outputPath))
                {
                    sw.WriteLine("BÁO CÁO DOANH THU PHÒNG VÉ");
                    sw.WriteLine("--------------------------");
                    int hang = 1;
                    foreach (var phim in rankedList)
                    {
                        sw.WriteLine($"Hạng: {hang}");
                        sw.WriteLine($"Tên phim: {phim.TenPhim}");
                        sw.WriteLine($"Số vé đã bán: {phim.SoVeDaBan}");
                        sw.WriteLine($"Số vé tồn: {phim.SoVeTon}");
                        sw.WriteLine($"Tỉ lệ vé bán ra: {phim.TiLeVeBan:P2}"); // P2: Format %
                        sw.WriteLine($"Tổng doanh thu: {phim.TongDoanhThu:N0} VNĐ");
                        sw.WriteLine("--------------------------");
                        hang++;
                    }
                }

                MessageBox.Show("Xuất báo cáo thành công! (output5.txt)", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                progressBar2.Value = 0; // Reset ProgressBar
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi ghi file báo cáo: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // 5. (THAY ĐỔI) MỞ FORM THỐNG KÊ MỚI
            // Thay vì chỉ hiện MessageBox, giờ ta mở Form mới
            FormThongKe formThongKeMoi = new FormThongKe(rankedList);
            formThongKeMoi.Show(); // Dùng .Show() để có thể mở nhiều cửa sổ
        }

        private void process1_Exited(object sender, EventArgs e)
        {

        }

        private void progressBar2_Click(object sender, EventArgs e)
        {

        }
    }
}
