﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing.Text;
using System.Text.Json;


namespace LAB2
{

    public partial class BAI4 : Form
    {
        List<SinhVien> danhSachInput = new List<SinhVien>();

        // Biến cho phần đọc file
        List<SinhVien> danhSachOutput; // Danh sách đọc từ file
        int chiSoHienTai = 0; // Vị trí (index) của sinh viên đang được hiển thị



        public BAI4()
        {
            InitializeComponent();

            // Vô hiệu hóa các nút điều hướng ban đầu
            btnTruoc.Enabled = false;
            btnSau.Enabled = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int mssv;
            if (!int.TryParse(txtMSSV_Input.Text, out mssv) || txtMSSV_Input.Text.Length != 8)
            {
                MessageBox.Show("Lỗi: MSSV phải là 8 chữ số.");
                return;
            }

            // Kiểm tra MSSV trùng
            if (danhSachInput.Any(sv => sv.MSSV == mssv))
            {
                MessageBox.Show("Lỗi: MSSV này đã tồn tại.");
                return;
            }

            if (txtDienThoai_Input.Text.Length != 10 || !txtDienThoai_Input.Text.StartsWith("0"))
            {
                MessageBox.Show("Lỗi: Số điện thoại phải có 10 chữ số và bắt đầu bằng 0.");
                return;
            }
            float diem1, diem2, diem3;
            if (!float.TryParse(txtDiem1_Input.Text, out diem1) || diem1 < 0 || diem1 > 10 ||
                !float.TryParse(txtDiem2_Input.Text, out diem2) || diem2 < 0 || diem2 > 10 ||
                !float.TryParse(txtDiem3_Input.Text, out diem3) || diem3 < 0 || diem3 > 10)
            {
                MessageBox.Show("Lỗi: Điểm phải là số từ 0 đến 10.");
                return; // Dừng lại nếu điểm không hợp lệ
            }
            SinhVien sv = new SinhVien
            {
                HoTen = txtHoTen_Input.Text,
                MSSV = mssv,
                DienThoai = txtDienThoai_Input.Text,
                Diem1 = diem1,
                Diem2 = diem2,
                Diem3 = diem3,
                DiemTrungBinh = 0 // Sẽ tính toán khi đọc file
            };

            // --- 3. Thêm vào danh sách và DataGridView ---
            danhSachInput.Add(sv);

            // Cập nhật RichTextBox (thay vì DataGridView)
            rtbDanhSach.Clear(); // Xóa nội dung cũ
            foreach (SinhVien item in danhSachInput)
            {
                rtbDanhSach.AppendText($"MSSV: {item.MSSV} - Tên: {item.HoTen}\n");
                rtbDanhSach.AppendText($"SĐT: {item.DienThoai}\n");
                rtbDanhSach.AppendText($"Điểm: {item.Diem1}, {item.Diem2}, {item.Diem3}\n");
                rtbDanhSach.AppendText("--------------------------------\n");
            }

            // --- 4. Xóa các ô input ---
            txtHoTen_Input.Clear();
            txtMSSV_Input.Clear();
            txtDienThoai_Input.Clear();
            txtDiem1_Input.Clear();
            txtDiem2_Input.Clear();
            txtDiem3_Input.Clear();

            MessageBox.Show("Thêm sinh viên thành công!");

        }



        private void btnWriteFile_Click(object sender, EventArgs e)
        {
            if (danhSachInput.Count == 0)
            {
                MessageBox.Show("Danh sách rỗng, không có gì để ghi.");
                return;
            }

            try
            {
                string jsonString = JsonSerializer.Serialize(danhSachInput, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText("input4.txt", jsonString);
                MessageBox.Show("Đã ghi file input4.txt (JSON) thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi ghi file: " + ex.Message);
            }

        }




        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReadFile_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Đọc file
                string jsonString = File.ReadAllText("input4.txt");
                danhSachOutput = JsonSerializer.Deserialize<List<SinhVien>>(jsonString);

                // 2. Tính toán
                foreach (SinhVien sv in danhSachOutput)
                {
                    sv.TinhDiemTrungBinh();
                }

                // 3. Ghi file output
                string jsonOutputString = JsonSerializer.Serialize(danhSachOutput, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText("output4.txt", jsonOutputString);

                // 4. Hiển thị
                chiSoHienTai = 0;
                HienThiSinhVien(chiSoHienTai);
                MessageBox.Show("Đã đọc, tính toán và ghi ra output4.txt (JSON) thành công.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đọc/xử lý file: " + ex.Message);
            }

        }

        private void HienThiSinhVien(int index)
        {
            if (danhSachOutput == null || danhSachOutput.Count == 0 || index < 0 || index >= danhSachOutput.Count)
            {
                // Xóa rỗng các ô nếu không có dữ liệu
                txtHoTen_Display.Clear();
                txtMSSV_Display.Clear();
                txtDienThoai_Display.Clear();
                txtDiem1_Display.Clear();
                txtDiem2_Display.Clear();
                txtDiem3_Display.Clear();
                txtDiemTB_Display.Clear();
                return;
            }

            SinhVien sv = danhSachOutput[index];

            txtHoTen_Display.Text = sv.HoTen;
            txtMSSV_Display.Text = sv.MSSV.ToString();
            txtDienThoai_Display.Text = sv.DienThoai;
            txtDiem1_Display.Text = sv.Diem1.ToString();
            txtDiem2_Display.Text = sv.Diem2.ToString();
            txtDiem3_Display.Text = sv.Diem3.ToString();
            txtDiemTB_Display.Text = sv.DiemTrungBinh.ToString("F2"); // Làm tròn 2 chữ số thập phân

            // Cập nhật trạng thái nút Back/Next (Pagination)
            btnTruoc.Enabled = (index > 0);
            btnSau.Enabled = (index < danhSachOutput.Count - 1);
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (danhSachOutput != null && chiSoHienTai < danhSachOutput.Count - 1)
            {
                chiSoHienTai++;
                HienThiSinhVien(chiSoHienTai);
            }
        }

        private void btnTruoc_Click(object sender, EventArgs e)
        {
            // LOGIC LÙI (Back)
            if (danhSachOutput != null && chiSoHienTai > 0)
            {
                chiSoHienTai--; // Dùng dấu -- (trừ) để lùi
                HienThiSinhVien(chiSoHienTai);
            }
        }

        private void btnSau_Click(object sender, EventArgs e)
        {
            // LOGIC TIẾN (Next)
            if (danhSachOutput != null && chiSoHienTai < danhSachOutput.Count - 1)
            {
                chiSoHienTai++; // Dùng dấu ++ (cộng) để tiến
                HienThiSinhVien(chiSoHienTai);
            }
        }

        private void dgvDanhSach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }
    }
}