﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB2
{
    public partial class BAI5_2 : Form
    {
        private string hoTen;
        private string tenPhim;
        private string phongChieu;
        private List<(string TenGhe, string LoaiGhe, int GiaVe)> thongTinDatVe;
        private int tongTien;

        public BAI5_2(string hoTen, string tenPhim, string phongChieu,
                           List<(string TenGhe, string LoaiGhe, int GiaVe)> thongTinDatVe, int tongTien)
        {
            InitializeComponent();
            this.hoTen = hoTen;
            this.tenPhim = tenPhim;
            this.phongChieu = phongChieu;
            this.thongTinDatVe = thongTinDatVe;
            this.tongTien = tongTien;

            this.Load += BAI5_2_Load;
        }


        private void HienThiThongTinThanhToan()
        {
            // Hiển thị thông tin lên các textbox
            textBox1.Text = hoTen; // Tên khách hàng
            textBox2.Text = tenPhim; // Tên phim
            textBox3.Text = phongChieu; // Phòng chiếu

            // Mã ghế (nối tất cả ghế đã chọn)
            string maGhe = string.Join(", ", thongTinDatVe.Select(x => x.TenGhe));
            textBox4.Text = maGhe;

            // Tổng tiền
            textBox5.Text = tongTien.ToString("N0") + " VNĐ";

            // Đặt textbox thành readonly
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void BAI5_2_Load(object sender, EventArgs e)
        {
            HienThiThongTinThanhToan();

            // Gán event handlers cho các button
            button1.Click += button1_Click; // Thanh Toán
            button2.Click += button2_Click; // Quay Lại
            button3.Click += button3_Click; // Thoát
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Mở file để ghi tiếp (append)
                string salesPath = Path.Combine(Application.StartupPath, "sales.txt");
                using (StreamWriter sw = new StreamWriter(salesPath, true))
                {
                    // Duyệt qua danh sách các vé đã chọn
                    foreach (var ve in thongTinDatVe)
                    {
                        // Lưu mỗi vé trên 1 dòng, cách nhau bằng dấu phẩy
                        // Format: TenKhachHang,TenPhim,PhongChieu,TenGhe,GiaVe
                        string line = $"{hoTen},{tenPhim},{phongChieu},{ve.TenGhe},{ve.GiaVe}";
                        sw.WriteLine(line);
                    }
                }

                MessageBox.Show("Thanh toán thành công! Đã lưu thông tin vé.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Quay về form chính BAI5 (giữ nguyên code cũ của bạn)
                this.Hide();
                // ... (code quay về form BAI5)
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lưu file vé: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            // Quay lại BAI5_1
            this.Hide();
            var formBAI5_1 = Application.OpenForms.OfType<BAI5_1>().FirstOrDefault();
            if (formBAI5_1 != null)
            {
                formBAI5_1.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Thoát chương trình
            Application.Exit();
        }
    }
}
