﻿using System.IO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.Data.Sqlite; // Add NuGet package: Microsoft.Data.Sqlite

namespace LAB2
{
    public partial class BAI6 : Form
    {
        private string dbPath = "Data Source=monan.db";
        private List<MonAn> monAnList = new List<MonAn>();
        private List<NguoiDung> nguoiDungList = new List<NguoiDung>();

        public BAI6()
        {
            InitializeComponent();
            InitDatabase();
            LoadNguoiDung(); // Phải load người dùng trước
            LoadMonAn();
            CapNhatListView();
            CapNhatComboBox(); // Cập nhật ComboBox
        }

        private void InitDatabase()
        {
            using (var conn = new SqliteConnection(dbPath))
            {
                conn.Open();
                var cmd = conn.CreateCommand();

                // Lệnh 1: Tạo bảng MonAn
                cmd.CommandText = @"
            CREATE TABLE IF NOT EXISTS MonAn (
                IDMA INTEGER PRIMARY KEY AUTOINCREMENT,
                TenMonAn TEXT,
                HinhAnh TEXT,
                IDNCC INTEGER
            );";
                cmd.ExecuteNonQuery(); // <-- Thực thi lệnh thứ nhất

                // Lệnh 2: Tạo bảng NguoiDung
                cmd.CommandText = @"
            CREATE TABLE IF NOT EXISTS NguoiDung (
                IDNCC INTEGER PRIMARY KEY AUTOINCREMENT,
                HoVaTen TEXT,
                QuyenHan TEXT
            );";
                cmd.ExecuteNonQuery(); // <-- Thực thi lệnh thứ hai
            }
        }
        private void LoadMonAn()
        {
            monAnList.Clear();
            using (var conn = new SqliteConnection(dbPath))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT IDMA, TenMonAn, HinhAnh, IDNCC FROM MonAn";
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        monAnList.Add(new MonAn
                        {
                            IDMA = reader.GetInt32(0),
                            TenMonAn = reader.GetString(1),
                            HinhAnh = reader.IsDBNull(2) ? "" : reader.GetString(2),
                            IDNCC = reader.GetInt32(3)
                        });
                    }
                }
            }
        }

        private void LoadNguoiDung()
        {
            nguoiDungList.Clear();
            using (var conn = new SqliteConnection(dbPath))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "SELECT IDNCC, HoVaTen, QuyenHan FROM NguoiDung";
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        nguoiDungList.Add(new NguoiDung
                        {
                            IDNCC = reader.GetInt32(0),
                            HoVaTen = reader.GetString(1),
                            QuyenHan = reader.IsDBNull(2) ? "" : reader.GetString(2)
                        });
                    }
                }
            }
        }

        // Cập nhật ComboBox để người dùng chọn
        private void CapNhatComboBox()
        {
            cmbNguoiDung.DataSource = null;
            cmbNguoiDung.DataSource = nguoiDungList;
            cmbNguoiDung.DisplayMember = "HoVaTen"; // Hiển thị tên
            cmbNguoiDung.ValueMember = "IDNCC"; // Giá trị là ID
        }

        private void CapNhatListView()
        {
            // Thiết lập ListView (nếu chưa làm trong Designer)
            listView1.View = View.Details;
            listView1.Columns.Clear();
            listView1.Columns.Add("ID", 50);
            listView1.Columns.Add("Tên Món Ăn", 150);
            listView1.Columns.Add("Người Đóng Góp", 150);
            listView1.Columns.Add("Hình Ảnh", 100);

            listView1.Items.Clear();
            foreach (var mon in monAnList)
            {
                var nguoi = nguoiDungList.FirstOrDefault(n => n.IDNCC == mon.IDNCC);
                var item = new ListViewItem(new[]
                {
                    mon.IDMA.ToString(),
                    mon.TenMonAn,
                    nguoi?.HoVaTen ?? "N/A", // Dùng ?? để tránh lỗi null
                    mon.HinhAnh
                });
                listView1.Items.Add(item);
            }
        }

        private void buttonThemMonAn_Click(object sender, EventArgs e)
        {
            // Giả sử có các TextBox: txtTenMonAn, txtHinhAnh, cmbNguoiDung
            if (string.IsNullOrWhiteSpace(txtTenMonAn.Text) || cmbNguoiDung.SelectedItem == null)
            {
                MessageBox.Show("Nhập đầy đủ thông tin món ăn và chọn người đóng góp.");
                return;
            }
            var selectedNguoiDung = (NguoiDung)cmbNguoiDung.SelectedItem;
            using (var conn = new SqliteConnection(dbPath))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO MonAn (TenMonAn, HinhAnh, IDNCC) VALUES (@ten, @hinh, @idncc)";
                cmd.Parameters.AddWithValue("@ten", txtTenMonAn.Text.Trim());
                cmd.Parameters.AddWithValue("@hinh", txtHinhAnh.Text.Trim());
                cmd.Parameters.AddWithValue("@idncc", selectedNguoiDung.IDNCC);
                cmd.ExecuteNonQuery();
            }
            LoadMonAn();
            CapNhatListView();
            txtTenMonAn.Clear();
            txtHinhAnh.Clear();
        }

        private void buttonThemNguoiDung_Click(object sender, EventArgs e)
        {
            // Giả sử có các TextBox: txtHoVaTen, txtQuyenHan
            if (string.IsNullOrWhiteSpace(txtHoVaTen.Text)) // Quyền hạn có thể để trống
            {
                MessageBox.Show("Nhập họ và tên người dùng.");
                return;
            }
            using (var conn = new SqliteConnection(dbPath))
            {
                conn.Open();
                var cmd = conn.CreateCommand();
                cmd.CommandText = "INSERT INTO NguoiDung (HoVaTen, QuyenHan) VALUES (@ten, @quyen)";
                cmd.Parameters.AddWithValue("@ten", txtHoVaTen.Text.Trim());
                cmd.Parameters.AddWithValue("@quyen", txtQuyenHan.Text.Trim());
                cmd.ExecuteNonQuery();
            }
            LoadNguoiDung();
            CapNhatComboBox(); // Cập nhật lại ComboBox
            txtHoVaTen.Clear();
            txtQuyenHan.Clear();
        }

        private void buttonChonNgauNhien_Click(object sender, EventArgs e)
        {
            if (monAnList.Count == 0)
            {
                MessageBox.Show("Danh sách món ăn trống!");
                return;
            }
            Random rnd = new Random();
            int index = rnd.Next(monAnList.Count);
            var mon = monAnList[index];
            var nguoi = nguoiDungList.FirstOrDefault(n => n.IDNCC == mon.IDNCC);

            // Hiển thị thông tin món ăn và người đóng góp
            txtKetQuaMonAn.Text = mon.TenMonAn;
            txtKetQuaNguoiDung.Text = nguoi?.HoVaTen ?? "N/A";

            // Hiển thị hình ảnh (giả sử ảnh nằm trong thư mục images)
            string imagePath = Path.Combine(Application.StartupPath, "images", mon.HinhAnh);
            if (!string.IsNullOrEmpty(mon.HinhAnh) && File.Exists(imagePath))
            {
                pictureBoxMonAn.Image = Image.FromFile(imagePath);
            }
            else
            {
                pictureBoxMonAn.Image = null; // Hoặc một ảnh mặc định
            }
        }

        // Giữ lại nút thoát
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnChonAnh_Click(object sender, EventArgs e)
        {
            // Mở cửa sổ chọn file
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                // Lọc chỉ cho phép chọn file ảnh
                dialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
                dialog.Title = "Chọn hình ảnh cho món ăn";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // 1. Lấy đường dẫn file người dùng đã chọn
                        string sourceFile = dialog.FileName;

                        // 2. Lấy tên file (ví dụ: "pho.jpg")
                        string fileName = Path.GetFileName(sourceFile);

                        // 3. Tạo đường dẫn đến thư mục "images" trong thư mục chạy .exe
                        // (Thư mục .exe là Application.StartupPath, thường là bin/Debug)
                        string appPath = Application.StartupPath;
                        string imagesFolder = Path.Combine(appPath, "images");

                        // 4. Tạo thư mục "images" nếu nó chưa tồn tại
                        Directory.CreateDirectory(imagesFolder);

                        // 5. Đường dẫn đích để copy file tới
                        string destPath = Path.Combine(imagesFolder, fileName);

                        // 6. Copy file từ nơi người dùng chọn vào thư mục images (true = cho phép ghi đè)
                        File.Copy(sourceFile, destPath, true);

                        // 7. Quan trọng: Gán tên file vào TextBox "Hình Ảnh"
                        txtHinhAnh.Text = fileName;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi sao chép ảnh: " + ex.Message);
                    }
                }
            }


        }

        // ĐỊNH NGHĨA CLASS MonAn VÀ NguoiDung
        public class MonAn
        {
            public int IDMA { get; set; }
            public string TenMonAn { get; set; }
            public string HinhAnh { get; set; }
            public int IDNCC { get; set; }
        }

        public class NguoiDung
        {
            public int IDNCC { get; set; }
            public string HoVaTen { get; set; }
            public string QuyenHan { get; set; }
        }
    }
}