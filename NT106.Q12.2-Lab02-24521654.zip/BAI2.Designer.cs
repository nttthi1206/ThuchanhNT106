﻿namespace LAB2
{
    partial class BAI2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtFileName = new TextBox();
            txtSize = new TextBox();
            txtUrl = new TextBox();
            txtLineCount = new TextBox();
            txtWordCount = new TextBox();
            txtCharCount = new TextBox();
            rtbContent = new RichTextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(32, 12);
            button1.Name = "button1";
            button1.Size = new Size(291, 39);
            button1.TabIndex = 0;
            button1.Text = " Read Form File";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnRead_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.Chartreuse;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ControlText;
            button2.Location = new Point(32, 399);
            button2.Name = "button2";
            button2.Size = new Size(291, 39);
            button2.TabIndex = 1;
            button2.Text = "EXIT ";
            button2.UseVisualStyleBackColor = false;
            button2.Click += btnExit_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 89);
            label1.Name = "label1";
            label1.Size = new Size(93, 20);
            label1.TabIndex = 2;
            label1.Text = " txtFileName";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(32, 135);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 3;
            label2.Text = "txtSize";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 187);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 4;
            label3.Text = " txtUrl";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(11, 245);
            label4.Name = "label4";
            label4.Size = new Size(100, 20);
            label4.TabIndex = 5;
            label4.Text = " txtLineCount ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(11, 301);
            label5.Name = "label5";
            label5.Size = new Size(105, 20);
            label5.TabIndex = 6;
            label5.Text = "txtWordCount ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(-3, 351);
            label6.Name = "label6";
            label6.Size = new Size(117, 20);
            label6.TabIndex = 7;
            label6.Text = " Character count";
            label6.Click += label6_Click;
            // 
            // txtFileName
            // 
            txtFileName.Location = new Point(119, 82);
            txtFileName.Name = "txtFileName";
            txtFileName.Size = new Size(204, 27);
            txtFileName.TabIndex = 8;
            // 
            // txtSize
            // 
            txtSize.Location = new Point(119, 128);
            txtSize.Name = "txtSize";
            txtSize.Size = new Size(204, 27);
            txtSize.TabIndex = 9;
            // 
            // txtUrl
            // 
            txtUrl.Location = new Point(119, 187);
            txtUrl.Name = "txtUrl";
            txtUrl.Size = new Size(204, 27);
            txtUrl.TabIndex = 10;
            // 
            // txtLineCount
            // 
            txtLineCount.Location = new Point(119, 242);
            txtLineCount.Name = "txtLineCount";
            txtLineCount.Size = new Size(204, 27);
            txtLineCount.TabIndex = 11;
            // 
            // txtWordCount
            // 
            txtWordCount.Location = new Point(119, 294);
            txtWordCount.Name = "txtWordCount";
            txtWordCount.Size = new Size(204, 27);
            txtWordCount.TabIndex = 12;
            // 
            // txtCharCount
            // 
            txtCharCount.Location = new Point(119, 344);
            txtCharCount.Name = "txtCharCount";
            txtCharCount.Size = new Size(204, 27);
            txtCharCount.TabIndex = 13;
            // 
            // rtbContent
            // 
            rtbContent.Location = new Point(348, 12);
            rtbContent.Name = "rtbContent";
            rtbContent.ScrollBars = RichTextBoxScrollBars.ForcedHorizontal;
            rtbContent.Size = new Size(440, 426);
            rtbContent.TabIndex = 14;
            rtbContent.Text = "";
            rtbContent.TextChanged += richTextBox1_TextChanged;
            // 
            // BAI2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(rtbContent);
            Controls.Add(txtCharCount);
            Controls.Add(txtWordCount);
            Controls.Add(txtLineCount);
            Controls.Add(txtUrl);
            Controls.Add(txtSize);
            Controls.Add(txtFileName);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "BAI2";
            Text = "BAI2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtFileName;
        private TextBox txtSize;
        private TextBox txtUrl;
        private TextBox txtLineCount;
        private TextBox txtWordCount;
        private TextBox txtCharCount;
        private RichTextBox rtbContent;
    }
}