﻿
using System;
using System.Collections.Generic; 
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAB2
{
    
    public partial class FormThongKe : Form
    {
        private List<PhimStats> bangThongKe;

        public FormThongKe(List<PhimStats> data)
        {
            InitializeComponent();
            this.bangThongKe = data; // Lưu dữ liệu
            this.Load += FormThongKe_Load; // Gán sự kiện Load
        }
        private void FormThongKe_Load(object sender, EventArgs e)
        {
            // Gán dữ liệu cho DataGridView
            dataGridView1.DataSource = bangThongKe;

            // (Tùy chọn) Làm đẹp tên các cột
            dataGridView1.Columns["TenPhim"].HeaderText = "Tên Phim";
            dataGridView1.Columns["SoVeDaBan"].HeaderText = "Vé Đã Bán";
            dataGridView1.Columns["SoVeTon"].HeaderText = "Vé Tồn";
            dataGridView1.Columns["TongDoanhThu"].HeaderText = "Doanh Thu";
            dataGridView1.Columns["TiLeVeBan"].HeaderText = "Tỉ Lệ Bán";

            // Định dạng cột Doanh Thu (thêm VNĐ)
            dataGridView1.Columns["TongDoanhThu"].DefaultCellStyle.Format = "N0' VNĐ'";
            // Định dạng cột Tỉ Lệ (thành %)
            dataGridView1.Columns["TiLeVeBan"].DefaultCellStyle.Format = "P2";
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
   public  class PhimStats
    {
        public string TenPhim { get; set; }
        public int SoVeDaBan { get; set; } = 0;
        public int SoVeTon { get; set; } = 0;
        public int TongDoanhThu { get; set; } = 0;
        public double TiLeVeBan => (SoVeDaBan + SoVeTon == 0) ? 0 : (double)SoVeDaBan / (SoVeDaBan + SoVeTon);
    }

}
