﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

[Serializable] // Đánh dấu để cho phép BinaryFormatter tuần tự hóa
public class SinhVien
{
    public string HoTen { get; set; }
    public int MSSV { get; set; }
    public string DienThoai { get; set; }
    public float Diem1 { get; set; }
    public float Diem2 { get; set; }
    public float Diem3 { get; set; }
    public float DiemTrungBinh { get; set; }

    // Phương thức tính điểm trung bình
    public void TinhDiemTrungBinh()
    {
        DiemTrungBinh = (Diem1 + Diem2 + Diem3) / 3;
    }
}