﻿namespace LAB2
{
    partial class BAI7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // ...existing code...
        // Remove all declarations and initialization for:
        // btnChonThuMuc, txtDuongDan, listView1, txtNoiDungFile, pictureBox1

        // Only keep:
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.GroupBox groupBoxContent;
        private System.Windows.Forms.RichTextBox richTextBoxContent;
        private System.Windows.Forms.PictureBox pictureBoxContent;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.groupBoxContent = new System.Windows.Forms.GroupBox();
            this.richTextBoxContent = new System.Windows.Forms.RichTextBox();
            this.pictureBoxContent = new System.Windows.Forms.PictureBox();
            this.groupBoxContent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxContent)).BeginInit();
            this.SuspendLayout();
            // 
            // treeView1
            // 
            this.treeView1.Location = new System.Drawing.Point(12, 12);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(250, 500);
            this.treeView1.TabIndex = 0;
            this.treeView1.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.treeView1_BeforeExpand);
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // groupBoxContent
            // 
            this.groupBoxContent.Controls.Add(this.richTextBoxContent);
            this.groupBoxContent.Controls.Add(this.pictureBoxContent);
            this.groupBoxContent.Location = new System.Drawing.Point(270, 12);
            this.groupBoxContent.Name = "groupBoxContent";
            this.groupBoxContent.Size = new System.Drawing.Size(600, 500);
            this.groupBoxContent.TabIndex = 1;
            this.groupBoxContent.TabStop = false;
            this.groupBoxContent.Text = "File Content";
            // 
            // richTextBoxContent
            // 
            this.richTextBoxContent.Location = new System.Drawing.Point(10, 22);
            this.richTextBoxContent.Name = "richTextBoxContent";
            this.richTextBoxContent.Size = new System.Drawing.Size(580, 470);
            this.richTextBoxContent.TabIndex = 0;
            this.richTextBoxContent.Text = "";
            this.richTextBoxContent.Visible = false;
            this.richTextBoxContent.ReadOnly = true;
            // 
            // pictureBoxContent
            // 
            this.pictureBoxContent.Location = new System.Drawing.Point(10, 22);
            this.pictureBoxContent.Name = "pictureBoxContent";
            this.pictureBoxContent.Size = new System.Drawing.Size(580, 470);
            this.pictureBoxContent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxContent.TabIndex = 1;
            this.pictureBoxContent.TabStop = false;
            this.pictureBoxContent.Visible = false;
            // 
            // BAI7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 524);
            this.Controls.Add(this.groupBoxContent);
            this.Controls.Add(this.treeView1);
            this.Name = "BAI7";
            this.Text = "BAI7";
            this.Load += new System.EventHandler(this.BAI7_Load);
            this.groupBoxContent.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxContent)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion
    }
}