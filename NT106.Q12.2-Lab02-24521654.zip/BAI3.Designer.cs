﻿namespace LAB2
{
    partial class BAI3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnRunBai3 = new Button();
            rtbContent = new RichTextBox();
            SuspendLayout();
            // 
            // btnRunBai3
            // 
            btnRunBai3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRunBai3.Location = new Point(30, 32);
            btnRunBai3.Name = "btnRunBai3";
            btnRunBai3.Size = new Size(102, 54);
            btnRunBai3.TabIndex = 0;
            btnRunBai3.Text = "Tính Toán";
            btnRunBai3.UseVisualStyleBackColor = true;
            btnRunBai3.Click += btnRunBai3_Click;
            // 
            // rtbContent
            // 
            rtbContent.Location = new Point(151, 22);
            rtbContent.Name = "rtbContent";
            rtbContent.Size = new Size(336, 203);
            rtbContent.TabIndex = 1;
            rtbContent.Text = "";
            rtbContent.TextChanged += richTextBox1_TextChanged;
            // 
            // BAI3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(499, 237);
            Controls.Add(rtbContent);
            Controls.Add(btnRunBai3);
            Name = "BAI3";
            Text = "BAI3";
            ResumeLayout(false);
        }

        #endregion

        private Button btnRunBai3;
        private RichTextBox rtbContent;
    }
}