﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI7 : Form
    {
        public BAI7()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text.Trim();
            string[] formats = { "dd/MM/yyyy", "dd/MM", "d/M/yyyy", "d/M" };

            if (!DateTime.TryParseExact(input, formats,System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out DateTime Ngaysinh))
            {
                MessageBox.Show("Vui lòng nhập ngày tháng hợp lệ (vd: 25/12/2023)", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            string cungHoangDao = XacDinhCungHoangDao(Ngaysinh.Day, Ngaysinh.Month);
            textBox2.Text = cungHoangDao;
        }

        private string XacDinhCungHoangDao(int day, int month)
        {
            string cung = "";
            switch (month)
            {
                case 1:
                    switch (day)
                    {
                        case >= 21:
                            cung = "Bảo Bình";
                            break;
                        default:
                            cung = "Ma Kết";
                            break;
                    }
                    break;
                case 2:
                    switch (day)
                    {
                        case >= 20:
                            cung = "Song Ngư";
                            break;
                        default:
                            cung = "Bảo Bình";
                            break;
                    }
                    break;
                case 3:
                    switch (day)
                    {
                        case >= 21:
                            cung = "Bạch Dương";
                            break;
                        default:
                            cung = "Song Ngư";
                            break;
                    }
                    break;
                case 4:
                    switch (day)
                    {
                        case >= 21:
                            cung = "Kim Ngưu";
                            break;
                        default:
                            cung = "Bạch Dương";
                            break;
                    }
                    break;
                case 5:
                    switch (day)
                    {
                        case >= 22:
                            cung = "Song Tử";
                            break;
                        default:
                            cung = "Kim Ngưu";
                            break;
                    }
                    break;
                case 6:
                    switch (day)
                    {
                        case >= 22:
                            cung = "Cự Giải";
                            break;
                        default:
                            cung = "Song Tử";
                            break;
                    }
                    break;
                case 7:
                    switch (day)
                    {
                        case >= 23:
                            cung = "Sư Tử";
                            break;
                        default:
                            cung = "Cự Giải";
                            break;
                    }
                    break;
                case 8:

                    switch (day)
                    {
                        case >= 24:
                            cung = "Xử Nữ";
                            break;
                        default:
                            cung = "Sư Tử";
                            break;
                    }
                    break;
                case 9:
                    switch (day)
                    {
                        case >= 24:
                            cung = "Thiên Bình";
                            break;
                        default:
                            cung = "Xử Nữ";
                            break;
                    }
                    break;
                case 10:
                    switch (day)
                    {
                        case >= 24:
                            cung = "Bọ Cạp";
                            break;
                        default:
                            cung = "Thiên Bình";
                            break;
                    }
                    break;
                case 11:
                    switch (day)
                    {
                        case >= 23:
                            cung = "Nhân Mã";
                            break;
                        default:
                            cung = "Bọ Cạp";
                            break;
                    }
                    break;
                case 12:
                    switch (day)
                    {
                        case >= 22:
                            cung = "Ma Kết";
                            break;
                        default:
                            cung = "Nhân Mã";
                            break;
                    }
                    break;
                default:
                    cung = "Không xác định";
                    break;
            }
            return cung;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
    }
}
