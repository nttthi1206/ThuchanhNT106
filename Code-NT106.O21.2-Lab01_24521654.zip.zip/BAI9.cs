﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI9 : Form
    {

        private string danhSachMonAn = "Tacos , Takoyaki, Sushi , Ramen , Banh Mi , Pho , Boba Tea , Kimchi , Bibimbap , Bulgogi, chô ni bi";
        private List<string> monAnList = new List<string>();
        public BAI9()
        {
            InitializeComponent();
            KhoiTaoDanhSach();
        }
        private void KhoiTaoDanhSach()
        {
            monAnList = danhSachMonAn.Split(',').Select(m => m.Trim()).Where(m => !string.IsNullOrEmpty(m)).ToList();
            CapNhatListBox();
        }

        private void CapNhatListBox()
        {
            listBox1.Items.Clear();
            foreach (var mon in monAnList)
            {
                listBox1.Items.Add(mon);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (monAnList.Count == 0)
            {
                textBox3.Text = "Danh sách trống!";
                return;
            }
            Random rnd = new Random();
            int index = rnd.Next(monAnList.Count);
            textBox3.Text = monAnList[index];
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string monMoi = textBox1.Text.Trim();
            if (!string.IsNullOrEmpty(monMoi))
            {
                monAnList.Add(monMoi);
                CapNhatListBox();
                textBox1.Text = "";
            }
            else
            {
                MessageBox.Show("Vui lòng nhập tên món ăn!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";

        }
    }
}

