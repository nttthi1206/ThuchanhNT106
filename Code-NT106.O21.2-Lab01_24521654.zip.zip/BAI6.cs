﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI6 : Form
    {
        public BAI6()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1.Text.Trim(), out int A) || !int.TryParse(textBox2.Text.Trim(), out int B))
            {
                MessageBox.Show("Vui lòng nhập số nguyên hợp lệ.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn phép toán.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string result = "";

            if (comboBox1.SelectedIndex == 0) //Bảng cửu chương 
            {
                result = TinhBangCuuChuong(B, A);
            }
            else if (comboBox1.SelectedIndex == 1) //Phép tính
            {
                result = TinhCacGiaTri(A, B);
            }

            label3.Text = result;
        }

        private string TinhBangCuuChuong(int B, int A)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 1; i <= A; i++)
            {
                sb.AppendLine($"{B} x {i} = {B * i}");
            }
            return sb.ToString();
        }

        private string TinhCacGiaTri(int A, int B)
        {
            StringBuilder sb = new StringBuilder();
            int diff = A - B;
            if (diff < 0)
            {
                sb.AppendLine($"(A-B)! = ({A} - {B})! = không tính được (không có giai thừa số âm)");
            }
            else
            {
                long factoria = TinhGiaiThua(diff);
                sb.AppendLine($"(A-B)! = ({A} - {B})! = {factoria}");
            }

            sb.AppendLine();

            if (B <= 0)
            {
                sb.AppendLine($"Tổng S = A^1 + A^2 + ... + A^B = {A}^1 + {A}^2 + ... + {A}^{B} = không tính được ( vì B <= 0 )");
            }

            else
            {
                long sum = 0;
                for (int i = 1; i <= B; i++)
                {
                    sum += (long)Math.Pow(A, i);
                }
                sb.AppendLine($"Tổng S = A^1 + A^2 + ... + A^B = {A}^1 + {A}^2 + ... + {A}^{B} = {sum}");
            }
            return sb.ToString();
        }

        private long TinhGiaiThua(int n)
        {
            if (n == 0 || n == 1)
                return 1;
            long result = 1;
            for (int i = 2; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (label3 != null)
            {
                label3.Text = "";
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            comboBox1.SelectedIndex = -1;
            if (label3 != null)
            {
                label3.Text = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
