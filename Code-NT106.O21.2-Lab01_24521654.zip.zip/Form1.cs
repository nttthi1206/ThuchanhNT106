namespace DEMO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BAI1 f = new BAI1();
            f.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            BAI2 f = new BAI2();
            f.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            BAI9 f = new BAI9();
            f.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            BAI3 f = new BAI3();
            f.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            BAI4 f = new BAI4();
            f.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            BAI6 f = new BAI6();
            f.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            BAI7 f = new BAI7();
            f.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            BAI8 f = new BAI8();
            f.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            BAI5 f = new BAI5();
            f.Show();
        }
    }
}
