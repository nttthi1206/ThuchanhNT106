﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI3 : Form
    {
        public BAI3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!int.TryParse(textBox1.Text, out int number) || number < 0 || number > 9)
            {
                MessageBox.Show("Vui lòng nhập số nguyên từ 0-9", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }
            string chuSo;
            switch (number)
            {
                case 0:
                    chuSo = "Không";
                    break;
                case 1:
                    chuSo = "Một";
                    break;
                case 2:
                    chuSo = "Hai";
                    break;
                case 3:
                    chuSo = "Ba";
                    break;
                case 4:
                    chuSo = "Bốn";
                    break;
                case 5:
                    chuSo = "Năm";
                    break;
                case 6:
                    chuSo = "Sáu";
                    break;
                case 7:
                    chuSo = "Bảy";
                    break;
                case 8:
                    chuSo = "Tám";
                    break;
                case 9:
                    chuSo = "Chín";
                    break;
                default:
                    chuSo = "";
                    break;
            }

            textBox2.Text = chuSo;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void BAI3_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
