﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI1 : Form
    {
        public BAI1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int so1, so2;


            if (!int.TryParse(textBox1.Text, out so1))
            {
                MessageBox.Show("Vui lòng nhập số nguyên!");
                return;
            }

            if (!int.TryParse(textBox2.Text, out so2))
            {
                MessageBox.Show("Vui lòng nhập số nguyên!");
                return;
            }

            int tong = so1 + so2;

            textBox3.Text = $"{tong}";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
