﻿namespace DEMO
{
    partial class BAI6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            comboBox1 = new ComboBox();
            groupBox1 = new GroupBox();
            label3 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            label1.Location = new Point(118, 42);
            label1.Name = "label1";
            label1.Size = new Size(50, 15);
            label1.TabIndex = 0;
            label1.Text = "Nhập A:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            label2.Location = new Point(449, 42);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 1;
            label2.Text = "Nhập B:";
            label2.Click += label2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            button1.Location = new Point(118, 164);
            button1.Name = "button1";
            button1.Size = new Size(158, 29);
            button1.TabIndex = 3;
            button1.Text = "Tính các giá trị ";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            button2.Location = new Point(348, 164);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 4;
            button2.Text = "Xóa";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            button3.Location = new Point(527, 164);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 5;
            button3.Text = "Thoát";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            textBox1.Location = new Point(191, 35);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 22);
            textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            textBox2.Location = new Point(527, 39);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 22);
            textBox2.TabIndex = 7;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Bảng cửu chương", "Tính toán giá trị " });
            comboBox1.Location = new Point(317, 97);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 23);
            comboBox1.TabIndex = 8;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label3);
            groupBox1.Font = new Font("Times New Roman", 7.8F, FontStyle.Bold);
            groupBox1.Location = new Point(63, 220);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(670, 232);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "Kết Quả";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(16, 27);
            label3.Name = "label3";
            label3.Size = new Size(16, 15);
            label3.TabIndex = 0;
            label3.Text = "...";
            label3.Click += label3_Click;
            // 
            // BAI6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(comboBox1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "BAI6";
            Text = "BAI6";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox1;
        private TextBox textBox2;
        private ComboBox comboBox1;
        private GroupBox groupBox1;
        private Label label3;
    }
}