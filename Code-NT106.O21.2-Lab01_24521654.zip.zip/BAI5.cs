﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI5 : Form
    {
        Dictionary<string, (int GiaVe, int[] PhongChieu)> danhSachPhim = new Dictionary<string, (int, int[])>()
        {
            {"Đào, phở và piano", (45000, new int[]{1,2,3})},
            {"Mai", (100000, new int[]{2,3})},
            {"Gặp lại chị bầu", (70000, new int[]{1})},
            {"Tarot", (90000, new int[]{3})}
        };

        public BAI5()
        {
            InitializeComponent();
            this.Load += BAI5_Load;
        }

        private void BAI5_Load(object sender, EventArgs e)
        {
            // Gán event handler cho comboBox1
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            
            // Xóa các items mặc định trong comboBox2
            comboBox2.Items.Clear();
            comboBox2.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CapNhatPhongChieu();
        }

        private void CapNhatPhongChieu()
        {
            // Xóa danh sách phòng chiếu hiện tại
            comboBox2.Items.Clear();
            comboBox2.Text = "";

            string tenPhimDaChon = comboBox1.Text;

            // Nếu có phim được chọn và tồn tại trong dictionary
            if (!string.IsNullOrEmpty(tenPhimDaChon) && danhSachPhim.ContainsKey(tenPhimDaChon))
            {
                var phongChieuArray = danhSachPhim[tenPhimDaChon].PhongChieu;
                
                // Thêm các phòng chiếu tương ứng vào comboBox2
                foreach (int phong in phongChieuArray)
                {
                    comboBox2.Items.Add(phong.ToString());
                }

                // Chọn option đầu tiên làm mặc định
                if (comboBox2.Items.Count > 0)
                {
                    comboBox2.SelectedIndex = 0;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tenPhim = comboBox1.Text;
            string phongChieu = comboBox2.Text;
            string hoTen = textBox1.Text;

            if (string.IsNullOrWhiteSpace(hoTen))
            {
                MessageBox.Show("Vui lòng nhập họ và tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(tenPhim))
            {
                MessageBox.Show("Vui lòng chọn phim!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(phongChieu))
            {
                MessageBox.Show("Vui lòng chọn phòng chiếu!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy giá vé từ dictionary
            if (danhSachPhim.ContainsKey(tenPhim))
            {
                int giaVe = danhSachPhim[tenPhim].GiaVe;
                BAI5_1 f = new BAI5_1(hoTen, tenPhim, phongChieu, giaVe);
                this.Hide();
                f.Show();
            }
            else
            {
                MessageBox.Show("Phim không tồn tại trong danh sách!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}


