﻿namespace DEMO
{
    partial class BAI8_KQ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(171, 34);
            label1.Name = "label1";
            label1.Size = new Size(402, 25);
            label1.TabIndex = 0;
            label1.Text = "THÔNG TIN ĐIỂM CỦA SINH VIÊN ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10.2F);
            label2.Location = new Point(217, 86);
            label2.Name = "label2";
            label2.Size = new Size(119, 19);
            label2.TabIndex = 1;
            label2.Text = "Họ tên sinh viên";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10.2F);
            label3.Location = new Point(92, 131);
            label3.Name = "label3";
            label3.Size = new Size(121, 19);
            label3.TabIndex = 2;
            label3.Text = "Danh sách điểm ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Times New Roman", 10.2F);
            label4.Location = new Point(92, 165);
            label4.Name = "label4";
            label4.Size = new Size(119, 19);
            label4.TabIndex = 3;
            label4.Text = "Điểm trung bình";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Times New Roman", 10.2F);
            label5.Location = new Point(92, 213);
            label5.Name = "label5";
            label5.Size = new Size(111, 19);
            label5.TabIndex = 4;
            label5.Text = "Điểm cao nhất ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Times New Roman", 10.2F);
            label6.Location = new Point(369, 213);
            label6.Name = "label6";
            label6.Size = new Size(115, 19);
            label6.TabIndex = 5;
            label6.Text = "Điểm thấp nhất ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Times New Roman", 10.2F);
            label7.Location = new Point(100, 283);
            label7.Name = "label7";
            label7.Size = new Size(89, 19);
            label7.TabIndex = 6;
            label7.Text = "Số môn đậu";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Times New Roman", 10.2F);
            label8.Location = new Point(369, 291);
            label8.Name = "label8";
            label8.Size = new Size(125, 19);
            label8.TabIndex = 7;
            label8.Text = "Số môn chưa đậu";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Times New Roman", 10.2F);
            label9.Location = new Point(180, 355);
            label9.Name = "label9";
            label9.Size = new Size(72, 19);
            label9.TabIndex = 8;
            label9.Text = "Xếp Loại";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Times New Roman", 10.2F);
            textBox1.Location = new Point(352, 83);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(209, 27);
            textBox1.TabIndex = 9;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Times New Roman", 10.2F);
            textBox2.Location = new Point(219, 127);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(552, 27);
            textBox2.TabIndex = 10;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Times New Roman", 10.2F);
            textBox3.Location = new Point(217, 160);
            textBox3.Name = "textBox3";
            textBox3.ReadOnly = true;
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 11;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Times New Roman", 10.2F);
            textBox4.Location = new Point(219, 210);
            textBox4.Name = "textBox4";
            textBox4.ReadOnly = true;
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 12;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Times New Roman", 10.2F);
            textBox5.Location = new Point(500, 213);
            textBox5.Name = "textBox5";
            textBox5.ReadOnly = true;
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 13;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Times New Roman", 10.2F);
            textBox6.Location = new Point(217, 275);
            textBox6.Name = "textBox6";
            textBox6.ReadOnly = true;
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 14;
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Times New Roman", 10.2F);
            textBox7.Location = new Point(500, 283);
            textBox7.Name = "textBox7";
            textBox7.ReadOnly = true;
            textBox7.Size = new Size(125, 27);
            textBox7.TabIndex = 15;
            // 
            // textBox8
            // 
            textBox8.Font = new Font("Times New Roman", 10.2F);
            textBox8.Location = new Point(268, 352);
            textBox8.Name = "textBox8";
            textBox8.ReadOnly = true;
            textBox8.Size = new Size(261, 27);
            textBox8.TabIndex = 16;
            // 
            // button1
            // 
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(299, 409);
            button1.Name = "button1";
            button1.Size = new Size(153, 29);
            button1.TabIndex = 17;
            button1.Text = "Thoát";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // BAI8_KQ
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "BAI8_KQ";
            Text = "BAI8_KQ";
            Load += BAI8_KQ_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private Button button1;
    }
}