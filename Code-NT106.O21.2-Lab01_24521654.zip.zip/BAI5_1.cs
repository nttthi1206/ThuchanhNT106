﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI5_1 : Form
    {
        private string hoTen;
        private string tenPhim;
        private string phongChieu;
        private int giaVeChuanPhim;

        private HashSet<Button> gheDaMua = new HashSet<Button>();
        private HashSet<Button> gheDangChon = new HashSet<Button>();

        // Dictionary để định nghĩa loại ghế và hệ số giá
        private Dictionary<string, (string LoaiGhe, double HeSoGia)> thongTinGhe = new Dictionary<string, (string, double)>()
        {
            // Ghế vớt (1/4 giá chuẩn)
            {"A1", ("Vớt", 0.25)}, {"A5", ("Vớt", 0.25)}, {"C1", ("Vớt", 0.25)}, {"C5", ("Vớt", 0.25)},
            
            // Ghế thường (giá chuẩn)
            {"A2", ("Thường", 1.0)}, {"A3", ("Thường", 1.0)}, {"A4", ("Thường", 1.0)},
            {"C2", ("Thường", 1.0)}, {"C3", ("Thường", 1.0)}, {"C4", ("Thường", 1.0)},
            
            // Ghế VIP (2 lần giá chuẩn)
            {"B1", ("Thường", 1.0)}, {"B2", ("VIP", 2.0)}, {"B3", ("VIP", 2.0)},
            {"B4", ("VIP", 2.0)}, {"B5", ("Thường", 1.0)}
        };

        public BAI5_1(string hoTen, string tenPhim, string phongChieu, int giaVe)
        {
            InitializeComponent();
            this.hoTen = hoTen;
            this.tenPhim = tenPhim;
            this.phongChieu = phongChieu;
            this.giaVeChuanPhim = giaVe;
            this.Load += BAI5_1_Load;
        }

        private void BAI5_1_Load(object sender, EventArgs e)
        {
            // Gán event click cho tất cả button trong groupBox và đặt tên ghế
            foreach (Control ctrl in groupBox1.Controls)
            {
                if (ctrl is Button btn)
                {
                    btn.BackColor = Color.White;
                    btn.Click += Ghe_Click;

                    // Đặt màu theo loại ghế
                    string tenGhe = btn.Text;
                    if (thongTinGhe.ContainsKey(tenGhe))
                    {
                        var loaiGhe = thongTinGhe[tenGhe].LoaiGhe;
                        switch (loaiGhe)
                        {
                            case "Vớt":
                                btn.BackColor = Color.LightGray;
                                break;
                            case "Thường":
                                btn.BackColor = Color.White;
                                break;
                            case "VIP":
                                btn.BackColor = Color.Gold;
                                break;
                        }
                    }
                }
            }

            // Đặt tên ghế cho các button (A1-A5, B1-B5, C1-C5)
            SetButtonNames();

            gheDaMua.Add(button3);
            gheDaMua.Add(button7);

            // Đặt màu đỏ cho ghế đã mua
            foreach (Button ghe in gheDaMua)
            {
                ghe.BackColor = Color.Red;
                ghe.Enabled = false;
            }
        }

        private void SetButtonNames()
        {
            // Đặt tên cho các button theo thứ tự A1-A5, B1-B5, C1-C5
            string[] tenGhe = {
                "A1", "A2", "A3", "A4", "A5",      // Hàng A
                "B1", "B2", "B3", "B4", "B5",      // Hàng B  
                "C1", "C2", "C3", "C4", "C5"       // Hàng C
            };

            Button[] buttons = {
                button1, button2, button3, button4, button5,
                button6, button7, button8, button9, button10,
                button11, button12, button13, button14, button15
            };

            for (int i = 0; i < buttons.Length && i < tenGhe.Length; i++)
            {
                buttons[i].Text = tenGhe[i];
            }
        }

        private void Ghe_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;

            // Nếu ghế đã mua rồi thì không làm gì
            if (gheDaMua.Contains(btn))
                return;

            // Nếu ghế đang được chọn → bỏ chọn
            if (gheDangChon.Contains(btn))
            {
                gheDangChon.Remove(btn);
                // Khôi phục màu gốc theo loại ghế
                string tenGhe = btn.Text;
                if (thongTinGhe.ContainsKey(tenGhe))
                {
                    var loaiGhe = thongTinGhe[tenGhe].LoaiGhe;
                    switch (loaiGhe)
                    {
                        case "Vớt":
                            btn.BackColor = Color.LightGray;
                            break;
                        case "Thường":
                            btn.BackColor = Color.White;
                            break;
                        case "VIP":
                            btn.BackColor = Color.Gold;
                            break;
                    }
                }
            }
            else
            {
                // Nếu đã chọn 2 ghế rồi → cảnh báo
                if (gheDangChon.Count >= 2)
                {
                    MessageBox.Show("Chỉ được chọn tối đa 2 ghế!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Chọn ghế
                gheDangChon.Add(btn);
                btn.BackColor = Color.Blue;
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (gheDangChon.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất 1 ghế!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Tính tổng tiền dựa trên loại ghế
            var thongTinDatVe = new List<(string TenGhe, string LoaiGhe, int GiaVe)>();
            int tongTien = 0;

            foreach (var ghe in gheDangChon)
            {
                string tenGhe = ghe.Text;
                if (thongTinGhe.ContainsKey(tenGhe))
                {
                    var (loaiGhe, heSoGia) = thongTinGhe[tenGhe];
                    int giaVe = (int)(giaVeChuanPhim * heSoGia);
                    thongTinDatVe.Add((tenGhe, loaiGhe, giaVe));
                    tongTien += giaVe;
                }
            }

            // Chuyển qua form thanh toán BAI5_2
            BAI5_2 formThanhToan = new BAI5_2(hoTen, tenPhim, phongChieu, thongTinDatVe, tongTien);
            this.Hide();
            formThanhToan.Show();

            // Đánh dấu ghế đã mua
            foreach (var ghe in gheDangChon)
            {
                ghe.BackColor = Color.Red;
                ghe.Enabled = false;
                gheDaMua.Add(ghe);
            }
            gheDangChon.Clear();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            this.Hide();
            var BAI5 = Application.OpenForms.OfType<BAI5>().FirstOrDefault();
            if (BAI5 != null)
            {
                BAI5.Show();
            }
            else
            {
                BAI5 newBAI5 = new BAI5();
                newBAI5.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}