﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI2 : Form
    {
        public BAI2()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();  // dùng để đóng form đang mở 
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool ok1 = double.TryParse(textBox1.Text, out double so1); // chuyển kiểu dữ liệu 
            bool ok2 = double.TryParse(textBox2.Text, out double so2);
            bool ok3 = double.TryParse(textBox3.Text, out double so3);


            if (ok1 && ok2 && ok3)
            {
                double max = so1;
                double min = so1;

                if (so2 > max) max = so2;
                if (so3 > max) max = so3;

                if (so2 < min) min = so2;
                if (so3 < min) min = so3;


                lblMax.Text = max.ToString();
                lblMin.Text = min.ToString();
            }
        }

        private void lblMin_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

            lblMax.Text = "";
            lblMin.Text = "";
        }
    }
}
