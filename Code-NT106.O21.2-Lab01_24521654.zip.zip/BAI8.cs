﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI8 : Form
    {
        public BAI8()
        {
            InitializeComponent();
            InitializeForm();
        }


        private void InitializeForm()
        {
            textBox1.Text = "Ví dụ: Nguyễn Thị A, 7.5, 5, 8, 10, 9, 10, 8.5, 9, 10, 3.5, 5.5, 2";
            textBox1.ForeColor = Color.Gray;

            textBox1.Enter += (s, e) => ClearPlaceholder();
            textBox1.Leave += (s, e) => SetPlaceholder();
        }

        private void ClearPlaceholder()
        {
            if (textBox1.ForeColor == Color.Gray)
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }

        private void SetPlaceholder()
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                textBox1.Text = "Ví dụ: Nguyễn Thị A, 7.5, 5, 8, 10, 9, 10, 8.5, 9, 10, 3.5, 5.5, 2";
                textBox1.ForeColor = Color.Gray;
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text.Trim();

            if (textBox1.ForeColor == Color.Gray || string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Vui lòng nhập họ tên và điểm của học sinh.", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }

            var ketQua = TachTenVaDiem(input);
            if (ketQua.hople)
            {
                BAI8_KQ f = new BAI8_KQ();
                f.HienThiThongTin(ketQua.ten, ketQua.diem);
                f.Show();
            }

        }

        private (bool hople, string ten, List<double> diem) TachTenVaDiem(string input)
        {
            try
            {
                // Tách chuỗi bằng dấu phẩy
                string[] parts = input.Split(',');

                if (parts.Length < 2)
                {
                    MessageBox.Show("Sai format! Vui lòng nhập theo định dạng: Tên, điểm1, điểm2, ...",
                                   "Lỗi Format", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return (false, "", new List<double>());
                }

                // Tách tên sinh viên (phần tử đầu tiên)
                string tenSinhVien = parts[0].Trim();

                if (string.IsNullOrWhiteSpace(tenSinhVien))
                {
                    MessageBox.Show("Tên sinh viên không được để trống!", "Lỗi",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return (false, "", new List<double>());
                }

                // Tách danh sách điểm (các phần tử còn lại)
                List<double> danhSachDiem = new List<double>();

                for (int i = 1; i < parts.Length; i++)
                {
                    if (double.TryParse(parts[i].Trim(), out double diem))
                    {
                        if (diem >= 0 && diem <= 10)
                        {
                            danhSachDiem.Add(diem);
                        }
                        else
                        {
                            MessageBox.Show($"Điểm {diem} không hợp lệ! Điểm phải từ 0 đến 10.",
                                           "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return (false, "", new List<double>());
                        }
                    }
                    else
                    {
                        MessageBox.Show($"Không thể chuyển đổi '{parts[i].Trim()}' thành điểm số!",
                                       "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return (false, "", new List<double>());
                    }
                }

                if (danhSachDiem.Count == 0)
                {
                    MessageBox.Show("Phải có ít nhất một điểm!", "Lỗi",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return (false, "", new List<double>());
                }

                return (true, tenSinhVien, danhSachDiem);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Có lỗi xảy ra: {ex.Message}", "Lỗi",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
                return (false, "", new List<double>());
            }
        }

        private void BAI8_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
