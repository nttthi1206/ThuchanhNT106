﻿namespace DEMO
{
    partial class BAI5_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button17 = new Button();
            button16 = new Button();
            groupBox1 = new GroupBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = SystemColors.GradientActiveCaption;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(84, 21);
            label1.Name = "label1";
            label1.Size = new Size(589, 62);
            label1.TabIndex = 0;
            label1.Text = "MÀN HÌNH";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(689, 102);
            label5.Name = "label5";
            label5.Size = new Size(108, 23);
            label5.TabIndex = 19;
            label5.Text = "<-- LỐI VÀO";
            // 
            // label6
            // 
            label6.BackColor = Color.Red;
            label6.Location = new Point(706, 146);
            label6.Name = "label6";
            label6.Size = new Size(81, 29);
            label6.TabIndex = 20;
            label6.Text = "Đã mua";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            label7.BackColor = SystemColors.ButtonShadow;
            label7.Location = new Point(706, 177);
            label7.Name = "label7";
            label7.Size = new Size(81, 30);
            label7.TabIndex = 21;
            label7.Text = "Đang chọn";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button17
            // 
            button17.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button17.Location = new Point(670, 397);
            button17.Name = "button17";
            button17.Size = new Size(117, 41);
            button17.TabIndex = 23;
            button17.Text = "Quay lại";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button16
            // 
            button16.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button16.Location = new Point(531, 397);
            button16.Name = "button16";
            button16.Size = new Size(122, 41);
            button16.TabIndex = 24;
            button16.Text = "Xác nhận";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(button15);
            groupBox1.Controls.Add(button14);
            groupBox1.Controls.Add(button13);
            groupBox1.Controls.Add(button12);
            groupBox1.Controls.Add(button11);
            groupBox1.Controls.Add(button10);
            groupBox1.Controls.Add(button9);
            groupBox1.Controls.Add(button8);
            groupBox1.Controls.Add(button7);
            groupBox1.Controls.Add(button6);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Location = new Point(133, 144);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(530, 223);
            groupBox1.TabIndex = 25;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 166);
            label4.Name = "label4";
            label4.Size = new Size(18, 20);
            label4.TabIndex = 17;
            label4.Text = "C";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 108);
            label3.Name = "label3";
            label3.Size = new Size(18, 20);
            label3.TabIndex = 16;
            label3.Text = "B";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 40);
            label2.Name = "label2";
            label2.Size = new Size(19, 20);
            label2.TabIndex = 15;
            label2.Text = "A";
            // 
            // button15
            // 
            button15.Location = new Point(430, 162);
            button15.Name = "button15";
            button15.Size = new Size(74, 29);
            button15.TabIndex = 14;
            button15.Text = "C5";
            button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.Location = new Point(340, 162);
            button14.Name = "button14";
            button14.Size = new Size(74, 29);
            button14.TabIndex = 13;
            button14.Text = "C4";
            button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.Location = new Point(248, 162);
            button13.Name = "button13";
            button13.Size = new Size(74, 29);
            button13.TabIndex = 12;
            button13.Text = "C3";
            button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.Location = new Point(152, 162);
            button12.Name = "button12";
            button12.Size = new Size(74, 29);
            button12.TabIndex = 11;
            button12.Text = "C2";
            button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(56, 162);
            button11.Name = "button11";
            button11.Size = new Size(74, 29);
            button11.TabIndex = 10;
            button11.Text = "C1";
            button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(430, 104);
            button10.Name = "button10";
            button10.Size = new Size(74, 29);
            button10.TabIndex = 9;
            button10.Text = "B5";
            button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(340, 104);
            button9.Name = "button9";
            button9.Size = new Size(74, 29);
            button9.TabIndex = 8;
            button9.Text = "B4";
            button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(248, 104);
            button8.Name = "button8";
            button8.Size = new Size(74, 29);
            button8.TabIndex = 7;
            button8.Text = " B3";
            button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(152, 104);
            button7.Name = "button7";
            button7.Size = new Size(74, 29);
            button7.TabIndex = 6;
            button7.Text = "B2";
            button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(56, 104);
            button6.Name = "button6";
            button6.Size = new Size(74, 29);
            button6.TabIndex = 5;
            button6.Text = " B1";
            button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(430, 34);
            button5.Name = "button5";
            button5.Size = new Size(74, 29);
            button5.TabIndex = 4;
            button5.Text = " A5";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(340, 34);
            button4.Name = "button4";
            button4.Size = new Size(74, 29);
            button4.TabIndex = 3;
            button4.Text = " A4";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(248, 34);
            button3.Name = "button3";
            button3.Size = new Size(74, 29);
            button3.TabIndex = 2;
            button3.Text = " A3";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(152, 34);
            button2.Name = "button2";
            button2.Size = new Size(74, 29);
            button2.TabIndex = 1;
            button2.Text = " A2";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(56, 34);
            button1.Name = "button1";
            button1.Size = new Size(74, 29);
            button1.TabIndex = 0;
            button1.Text = " A1";
            button1.UseVisualStyleBackColor = true;
            // 
            // BAI5_1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(button16);
            Controls.Add(button17);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label1);
            Name = "BAI5_1";
            Text = "BAI5_1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button17;
        private Button button16;
        private GroupBox groupBox1;
        private Button button15;
        private Button button14;
        private Button button13;
        private Button button12;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label4;
        private Label label3;
        private Label label2;
    }
}