﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI8_KQ : Form
    {
        public BAI8_KQ()
        {
            InitializeComponent();
        }

        public void HienThiThongTin(string tenSinhVien, List<double> danhSachDiem)
        {
            textBox1.Text = tenSinhVien;

            StringBuilder danhSachDiemStr = new StringBuilder();
            for (int i = 0; i < danhSachDiem.Count; i++)
            {
                danhSachDiemStr.Append($"Môn {i + 1}: {danhSachDiem[i]}");
                if (i < danhSachDiem.Count - 1)
                    danhSachDiemStr.Append("    ");
            }
            textBox2.Text = danhSachDiemStr.ToString();

            double diemTrungBinh = danhSachDiem.Average();
            textBox3.Text = diemTrungBinh.ToString("F2");

            double diemCaoNhat = danhSachDiem.Max();
            double diemThapNhat = danhSachDiem.Min();
            textBox4.Text = diemCaoNhat.ToString();
            textBox5.Text = diemThapNhat.ToString();

            int soMonDau = danhSachDiem.Count(d => d >= 5.0);
            int soMonKhongDau = danhSachDiem.Count - soMonDau;
            textBox6.Text = soMonDau.ToString();
            textBox7.Text = soMonKhongDau.ToString();

            string xepLoai = XepLoaiSinhVien(diemTrungBinh, danhSachDiem);
            textBox8.Text = xepLoai;
        }

        private string XepLoaiSinhVien(double diemTrungBinh, List<double> danhSachDiem)
        {

            if (diemTrungBinh >= 8 && danhSachDiem.All(d => d >= 6.5))
            {
                return "Giỏi";
            }

            else if (diemTrungBinh >= 6.5 && danhSachDiem.All(d => d >= 5))
            {
                return "Khá";
            }
            else if (diemTrungBinh >= 5 && danhSachDiem.All(d => d >= 3.5))
            {
                return "Trung Bình";
            }
            else if (diemTrungBinh >= 3.5 && danhSachDiem.All(d => d >= 2))
            {
                return "Yếu";
            }
            else
            {
                return "Kém";
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void BAI8_KQ_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
