﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace DEMO
{
    public partial class BAI4 : Form
    {
        public BAI4()
        {
            InitializeComponent();
        }

        private void BAI4_Load(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text.Trim();

            if (!long.TryParse(input, out long number) || input.Length > 12 || input.Length == 0)
            {
                MessageBox.Show("Vui lòng nhập số nguyên có tối đa 12 chữ số", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                return;
            }
            textBox2.Text = DocSoThanhChu(number);
        }

        private string DocSoThanhChu(long number)
        {
            if (number == 0) return "Không";

            string[] donVi = { "", "ngàn", "triệu", "tỷ" };
            string result = "";
            int donViIndex = 0;
            while (number > 0)
            {
                int group = (int)(number % 1000);
                if (group > 0)
                {
                    string groupText = DocBaSo(group);
                    if (donViIndex > 0 && groupText != "")
                        result = groupText + " " + donVi[donViIndex] + (result != "" ? ", " : "") + result;
                    else
                        result = groupText + (result != "" ? ", " : "") + result;

                }
                number /= 1000;
                donViIndex++;
            }
            if (!string.IsNullOrEmpty(result))
            {
                result = char.ToUpper(result[0]) + result.Substring(1);

                return result.Trim();
            }
            return "";
        }

        private string DocBaSo(int number)
        {
            string[] chuSo = { "không", "một", "hai", "ba", "bốn", "năm", "sáu", "bảy", "tám", "chín" };
            int tram = number / 100;
            int chuc = (number % 100) / 10;
            int donvi = number % 10;
            string result = "";

            if (tram > 0)
                result += chuSo[tram] + " trăm";
            else if (chuc > 0 || donvi > 0)
                result += "không trăm";

            if (chuc > 1)
            {
                result += " " + chuSo[chuc] + " mươi";
                if (donvi == 1) result += " mốt";
                else if (donvi == 5) result += " lăm";
                else if (donvi > 0) result += " " + chuSo[donvi];
            }
            else if (chuc == 1)
            {
                result += " mười";
                if (donvi == 5) result += " lăm";
                else if (donvi > 0) result += " " + chuSo[donvi];
            }
            else if (donvi > 0)
            {
                result += " " + chuSo[donvi];
            }

            return result.Trim();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";


        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
